//
//  HttpRequest.swift
//  iOSProject
//
//  Created by Kaira NewMac on 12/9/16.
//  Copyright © 2016 Kaira NewMac. All rights reserved.
//

import UIKit
import Foundation
import Alamofire
import AlamofireObjectMapper
import ObjectMapper

class HttpRequest: NSObject {
    
    class func serviceResponse(url: String, HttpMethod: HTTPMethod, InputParameter: Parameters, ServiceCallBack: @escaping (_ result: String?, _ response: ServiceResponseMessage)-> Void!) {
    
        if Reachability.isConnectedToNetwork(){
        
//            let headers = [
//                "Content-Type": "application/json"
//            ]
            request(url, method:HttpMethod,parameters:InputParameter, encoding:JSONEncoding.default, headers: nil).responseJSON { response in
                
                if(response.result.isSuccess){
                    
                    let datastring = NSString(data:response.data!, encoding:String.Encoding.utf8.rawValue) as String?
//                    print("ResponseString:",datastring)
//                    let jsonDictionary =  JSONData().onvertToDictionary(text: datastring!) as NSDictionary!
//                    print("Response : ", jsonDictionary as Any)
                    let serviceresponse = Mapper<ServiceResponseMessage>().map(JSONString: datastring!)
//                    let str = Mapper().toJSONString(serviceresponse, prettyPrint: true)
//                    print(serviceresponse?.description)
                    ServiceCallBack(datastring, serviceresponse!)
                   
                }else{
//                    print(response.result.error?.localizedDescription as Any)
                    let serviceReponse = ServiceResponseMessage()
                    HttpParameter.CurrentHttpCode = HttpCode.Error_503
                    serviceReponse?.IsSuccess = false
                    serviceReponse?.Code = HttpCode.Error_503.rawValue
                    serviceReponse?.Message = (response.result.error?.localizedDescription)! as String
                    ServiceCallBack(nil, serviceReponse!)
                }
            }
        }
        else {
            
            let serviceReponse = ServiceResponseMessage()
            HttpParameter.CurrentHttpCode = HttpCode.Error_504
            serviceReponse?.Code = HttpCode.Error_504.rawValue
            serviceReponse?.IsSuccess = false
            serviceReponse?.Message = AppMessage.NoInternetConnection
            ServiceCallBack(nil,serviceReponse!)
        }
    }
    
    class func serviceResponsePHP(url: String, HttpMethod: HTTPMethod, InputParameter: Parameters, ServiceCallBack: @escaping (_ result: String?, _ response: ServiceResponseMessage)-> Void!) {
        
        if Reachability.isConnectedToNetwork(){
            Alamofire.request(url, method:HttpMethod, parameters: InputParameter).validate().responseJSON {
                response in
                                if(response.result.isSuccess){
                
                                    let datastring = NSString(data:response.data!, encoding:String.Encoding.utf8.rawValue) as String?
                                    let serviceresponse = Mapper<ServiceResponseMessage>().map(JSONString: datastring!)
                                    ServiceCallBack(datastring, serviceresponse!)
                                }else{
                                    let serviceReponse = ServiceResponseMessage()
                                    HttpParameter.CurrentHttpCode = HttpCode.Error_503
                                    serviceReponse?.IsSuccess = false
                                    serviceReponse?.Code = HttpCode.Error_503.rawValue
                                    serviceReponse?.Message = (response.result.error?.localizedDescription)! as String
                                    ServiceCallBack(nil, serviceReponse!)
                                }
                    }
        }
        else {
            let serviceReponse = ServiceResponseMessage()
            HttpParameter.CurrentHttpCode = HttpCode.Error_504
            serviceReponse?.Code = HttpCode.Error_504.rawValue
            serviceReponse?.IsSuccess = false
            serviceReponse?.Message = AppMessage.NoInternetConnection
            ServiceCallBack(nil,serviceReponse!)
        }
    }
    
    func serviceCallMultipleImageUploadHTTP(imageData: [Data] = [],url: String,HttpMethod: HTTPMethod , parameter: [String:String]? = nil ,viewController:UIViewController? = nil, ServiceCallBack: @escaping (_ result: String?, _ response: ServiceResponseMessage)-> Void!)
    {
        if(Reachability.isConnectedToNetwork())
        {
            Alamofire.upload(multipartFormData: { (multipartFormData) in
                
                
                for i in 0..<(imageData.count){
                    multipartFormData.append(imageData[i] as Data, withName: "photo_path", fileName: "uploaded_file.jpg", mimeType: "image/jpg")
                }
                
                for (key, value) in parameter! {
                    multipartFormData.append((value as AnyObject).data(using: String.Encoding.utf8.rawValue)!, withName: key )
                }
                
                //  print("mutlipart 2st \(multipartFormData)")
            }, to:url)
            { (result) in
                switch result {
                case .success(let upload, _, _):
                    
                    upload.uploadProgress(closure: { (Progress) in
//                        if let view = viewController as? CreateProductImageVC {
//                            view.IBimgProgress.isHidden = false
////                            print("Progress : \(Float(Progress.fractionCompleted))")
//                            view.IBimgProgress.setProgress(Float(Progress.fractionCompleted), animated: true)
//                        }
                    })
                    upload.responseJSON { response in
//                        if let view = viewController as? CreateProductImageVC {
//                            view.IBimgProgress.isHidden = true
//                            view.IBConstProgress.constant = 0
//                            view.IBimgProgress.progress = 0.0
//                        }
                        
                        
                        if(response.result.isSuccess){
                            let datastring = NSString(data:response.data!, encoding:String.Encoding.utf8.rawValue) as String?
                            let serviceresponse = Mapper<ServiceResponseMessage>().map(JSONString: datastring!)
                            ServiceCallBack(datastring, serviceresponse!)
                        }else{
//                            print(response.result.error?.localizedDescription as Any)
                            let serviceReponse = ServiceResponseMessage()
                            HttpParameter.CurrentHttpCode = HttpCode.Error_503
                            serviceReponse?.IsSuccess = false
                            serviceReponse?.Message = (response.result.error?.localizedDescription)! as String
                            ServiceCallBack(nil, serviceReponse!)
                        }
                    }
                case .failure(let encodingError):
                    //self.delegate?.showFailAlert()
                    print(encodingError)
                }
            }
        } else {
            let serviceReponse = ServiceResponseMessage()
            HttpParameter.CurrentHttpCode = HttpCode.Error_504
            serviceReponse?.Code = HttpCode.Error_504.rawValue
            serviceReponse?.IsSuccess = false
            serviceReponse?.Message = AppMessage.NoInternetConnection
            ServiceCallBack(nil,serviceReponse!)
        }
    }
    
    func serviceCallMultipleImageUploadWithPath(imagesPath:[URL]?, url: String,HttpMethod: HTTPMethod , parameter: [String:String]? = nil ,viewController:UIViewController? = nil, ServiceCallBack: @escaping (_ result: String?, _ response: ServiceResponseMessage)-> Void!)
    {
        if(Reachability.isConnectedToNetwork())
        {
            Alamofire.upload(multipartFormData: { (multipartFormData) in
//                for i in 0..<(imageData.count){
//                    multipartFormData.append(imageData[i] as Data, withName: "photo_path", fileName: "uploaded_file.png", mimeType: "image/png")
//                }
//                
//                for (key, value) in parameter! {
//                    multipartFormData.append((value as AnyObject).data(using: String.Encoding.utf8.rawValue)!, withName: key )
//                }
                if let imgPathList = imagesPath {
                    for i in 0..<(imgPathList.count){
                        multipartFormData.append(imgPathList[i], withName: "photo_path")
                    }
                }
                
                
                
                
//                multipartFormData.append(strLocalPath, withName: "photo_path")
                
                for (key, value) in parameter! {
                    multipartFormData.append((value as AnyObject).data(using: String.Encoding.utf8.rawValue)!, withName: key )
                }
                
                //  print("mutlipart 2st \(multipartFormData)")
            }, to:url)
            { (result) in
                switch result {
                case .success(let upload, _, _):
                    
                    upload.uploadProgress(closure: { (Progress) in
                        //                        if let view = viewController as? CreateProductImageVC {
                        //                            view.IBimgProgress.isHidden = false
                        ////                            print("Progress : \(Float(Progress.fractionCompleted))")
                        //                            view.IBimgProgress.setProgress(Float(Progress.fractionCompleted), animated: true)
                        //                        }
                    })
                    upload.responseJSON { response in
                        //                        if let view = viewController as? CreateProductImageVC {
                        //                            view.IBimgProgress.isHidden = true
                        //                            view.IBConstProgress.constant = 0
                        //                            view.IBimgProgress.progress = 0.0
                        //                        }
                        
                        
                        if(response.result.isSuccess){
                            let datastring = NSString(data:response.data!, encoding:String.Encoding.utf8.rawValue) as String?
                            let serviceresponse = Mapper<ServiceResponseMessage>().map(JSONString: datastring!)
                            ServiceCallBack(datastring, serviceresponse!)
                        }else{
                            //                            print(response.result.error?.localizedDescription as Any)
                            let serviceReponse = ServiceResponseMessage()
                            HttpParameter.CurrentHttpCode = HttpCode.Error_503
                            serviceReponse?.IsSuccess = false
                            serviceReponse?.Message = (response.result.error?.localizedDescription)! as String
                            ServiceCallBack(nil, serviceReponse!)
                        }
                    }
                case .failure(let encodingError):
                    //self.delegate?.showFailAlert()
                    print(encodingError)
                }
            }
        } else {
            let serviceReponse = ServiceResponseMessage()
            HttpParameter.CurrentHttpCode = HttpCode.Error_504
            serviceReponse?.Code = HttpCode.Error_504.rawValue
            serviceReponse?.IsSuccess = false
            serviceReponse?.Message = AppMessage.NoInternetConnection
            ServiceCallBack(nil,serviceReponse!)
        }
    }
    

    //mehul
    func serviceCallMultipleCategoryImageUploadHTTP(imageData: CategoryImageDataUpload<CategoryImagesNSDataList>,url: String,HttpMethod: HTTPMethod , parameter: [String:String]? = nil ,viewController:UIViewController? = nil,imageKey:String?="", ServiceCallBack: @escaping (_ result: String?, _ response: ServiceResponseMessage)-> Void!)
    {
        if(Reachability.isConnectedToNetwork())
        {
            Alamofire.upload(multipartFormData: { (multipartFormData) in
                                
                for i in 0..<(imageData.CategoryImagesNSDataList?.count)!{
                    //multipartFormData.append(imageData[i] as Data, withName: imageKey!, fileName: "uploaded_file.jpeg", mimeType: "image/jpeg")
                    multipartFormData.append((imageData.CategoryImagesNSDataList?[i].Data as! Data), withName: (imageData.CategoryImagesNSDataList?[i].Key)!, fileName: "uploaded_file.jpeg", mimeType: "image/jpeg")
                }
                
                for (key, value) in parameter! {
                    multipartFormData.append((value as AnyObject).data(using: String.Encoding.utf8.rawValue)!, withName: key )
                }
                
                //  print("mutlipart 2st \(multipartFormData)")
            }, to:url)
            { (result) in
                switch result {
                case .success(let upload, _, _):
                    
                    upload.uploadProgress(closure: { (Progress) in
//                        if let view = viewController as? CreateProductImageVC {
//                            
//                            view.IBimgProgress.isHidden = false
//                            //                            print("Progress : \(Float(Progress.fractionCompleted))")
//                            view.IBimgProgress.setProgress(Float(Progress.fractionCompleted), animated: true)
//                        }
                        
                    })
                    upload.responseJSON { response in
                        
//                        if let view = viewController as? CreateProductImageVC {
//                            view.IBimgProgress.isHidden = true
//                            view.IBConstProgress.constant = 0
//                            view.IBimgProgress.progress = 0.0
//                        }
                        
                        
                        if(response.result.isSuccess){
                            let datastring = NSString(data:response.data!, encoding:String.Encoding.utf8.rawValue) as String?
                            let serviceresponse = Mapper<ServiceResponseMessage>().map(JSONString: datastring!)
                            ServiceCallBack(datastring, serviceresponse!)
                        }else{
                            //                            print(response.result.error?.localizedDescription as Any)
                            let serviceReponse = ServiceResponseMessage()
                            HttpParameter.CurrentHttpCode = HttpCode.Error_503
                            serviceReponse?.IsSuccess = false
                            serviceReponse?.Message = (response.result.error?.localizedDescription)! as String
                            ServiceCallBack(nil, serviceReponse!)
                        }
                    }
                case .failure(let encodingError):
                    //self.delegate?.showFailAlert()
                    print(encodingError)
                }
            }
        } else {
            let serviceReponse = ServiceResponseMessage()
            HttpParameter.CurrentHttpCode = HttpCode.Error_504
            serviceReponse?.Code = HttpCode.Error_504.rawValue
            serviceReponse?.IsSuccess = false
            serviceReponse?.Message = AppMessage.NoInternetConnection
            ServiceCallBack(nil,serviceReponse!)
        }
    }
    
    //mehul
    func serviceCallImageUpload(imageData: Data? = nil ,url: String,HttpMethod: HTTPMethod , parameter: [String:String]? = nil , ServiceCallBack: @escaping (_ result: String?, _ response: ServiceResponseMessage)-> Void!)
    {
        if(Reachability.isConnectedToNetwork())
        {
                Alamofire.upload(multipartFormData: { (multipartFormData) in
                    
                    if imageData != nil {
                        multipartFormData.append(imageData! as Data, withName: "photo_path", fileName: "uploaded_file.jpeg", mimeType: "image/jpeg")
                    }
//                    print("mutlipart 1st \(multipartFormData)")
//                    print("Parameters : \(parameter)")
                    
//                    for (key, value) in parameter! {
//                        multipartFormData.append((value as AnyObject).data(using: String.Encoding.utf8.rawValue)!, withName: key )
//                    }
                    
                    for (key, value) in parameter! {
                        multipartFormData.append((value as AnyObject).data(using: String.Encoding.utf8.rawValue)!, withName: key )
                    }
                    
                  //  print("mutlipart 2st \(multipartFormData)")
                }, to:url)
                { (result) in
                    switch result {
                    case .success(let upload, _, _):
                        
                        upload.uploadProgress(closure: { (Progress) in
                            //                            if let view = uiviewController as? RegistrationVC {
                            //                                view.imgProgress.isHidden = false
                            //                                view.imgProgress.setProgress(Float(Progress.fractionCompleted), animated: true)
                            //                            }
                            
                        })
                        upload.responseJSON { response in
                            //self.delegate?.showSuccessAlert()
                            
                            //                            if let view = uiviewController as? RegistrationVC {
                            //                                view.imgProfile.alpha = 1
                            //                                view.imgProgress.isHidden = true
                            //                                view.imgProgress.progress = 0.0
                            //                            }
                            
                            
                            if(response.result.isSuccess){
                                let datastring = NSString(data:response.data!, encoding:String.Encoding.utf8.rawValue) as String?
                                let serviceresponse = Mapper<ServiceResponseMessage>().map(JSONString: datastring!)
                                ServiceCallBack(datastring, serviceresponse!)
                            }else{
//                                print(response.result.error?.localizedDescription as Any)
                                let serviceReponse = ServiceResponseMessage()
                                HttpParameter.CurrentHttpCode = HttpCode.Error_503
                                serviceReponse?.IsSuccess = false
                                serviceReponse?.Message = (response.result.error?.localizedDescription)! as String
                                ServiceCallBack(nil, serviceReponse!)
                            }
                        }
                    case .failure(let encodingError):
                        //self.delegate?.showFailAlert()
                        print(encodingError)
                    }
            }
        } else {
            let serviceReponse = ServiceResponseMessage()
            HttpParameter.CurrentHttpCode = HttpCode.Error_504
            serviceReponse?.Code = HttpCode.Error_504.rawValue
            serviceReponse?.IsSuccess = false
            serviceReponse?.Message = AppMessage.NoInternetConnection
            ServiceCallBack(nil,serviceReponse!)
        }
    }
    /*
    //Implement Image Upload using FilePath
    func serviceCallMultipleFileUploadHTTP(objFilePath:[LoginGetModel], url: String,HttpMethod: HTTPMethod , parameter: [String:String]? = nil ,viewController:UIViewController? = nil, ServiceCallBack: @escaping (_ result: String?, _ response: ServiceResponseMessage)-> Void!)
    {
        if(Reachability.isConnectedToNetwork())
        {
            Alamofire.upload(multipartFormData: { (multipartFormData) in
                
                let DirPath = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0]
                let documentDirectory = URL(fileURLWithPath: DirPath)
                
                for i in 0..<(objFilePath.count){
                    let imageURL                =  documentDirectory.appendingPathComponent(objFilePath[i].City!)
                    multipartFormData.append(imageURL, withName: "photo_path")
//                    multipartFormData.append(imageURL, withName: "photo_path", fileName: <#T##String#>, mimeType: <#T##String#>)
//                    multipartFormData.append(imageData! as Data, withName: "photo_path", fileName: "uploaded_file.jpeg", mimeType: "image/jpeg")
                }
//                let DirPath = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0]
//                let documentDirectory = URL(fileURLWithPath: DirPath)
//                let imageURL                =  documentDirectory.appendingPathComponent(objDocumentModel.LocalPath!)
//                multipartFormData.append(imageURL, withName: "UploadDocument")
                
                for (key, value) in parameter! {
                    multipartFormData.append((value as AnyObject).data(using: String.Encoding.utf8.rawValue)!, withName: key )
                }
            }, to: url, encodingCompletion: { (result) in
                switch result {
                case .success(let upload, _, _):
                    
                    upload.uploadProgress(closure: { (Progress) in
                        
                    })
                    upload.responseJSON { response in
                        
                        if(response.result.isSuccess){
                            let datastring = NSString(data:response.data!, encoding:String.Encoding.utf8.rawValue) as String?
                            let serviceresponse = Mapper<ServiceResponseMessage>().map(JSONString: datastring!)
                            ServiceCallBack(datastring, serviceresponse!)
                        }else{
                            //                            print(response.result.error?.localizedDescription as Any)
                            let serviceReponse = ServiceResponseMessage()
                            HttpParameter.CurrentHttpCode = HttpCode.Error_503
                            serviceReponse?.IsSuccess = false
                            serviceReponse?.Message = (response.result.error?.localizedDescription)! as String
                            ServiceCallBack(nil, serviceReponse!)
                        }
                    }
                case .failure(let encodingError):
                    //self.delegate?.showFailAlert()
                    print(encodingError)
                }
            })
        } else {
            let serviceReponse = ServiceResponseMessage()
            HttpParameter.CurrentHttpCode = HttpCode.Error_504
            serviceReponse?.Code = HttpCode.Error_504.rawValue
            serviceReponse?.IsSuccess = false
            serviceReponse?.Message = AppMessage.NoInternetConnection
            ServiceCallBack(nil,serviceReponse!)
        }
    }
    */
}


//MARK: - Multiple Images uploading.
extension HttpRequest {
    
    func serviceCallMultipleImageUploadHTTPArr(imgURLs: [URL], url: String, HttpMethod: HTTPMethod , parameter: [String:String]? = nil ,viewController:UIViewController? = nil, ServiceCallBack: @escaping (_ result: String?, _ response: ServiceResponseMessage)-> Void!) {
        if(Reachability.isConnectedToNetwork())
        {
            Alamofire.upload(multipartFormData: { (multipartFormData) in
                
                for i in 0..<(imgURLs.count){
                    multipartFormData.append(imgURLs[i], withName: "photo_path", fileName: "uploaded_file.jpeg", mimeType: "image/jpeg")
                }
                for (key, value) in parameter! {
                    multipartFormData.append((value as AnyObject).data(using: String.Encoding.utf8.rawValue)!, withName: key )
                }
            }, to: url, encodingCompletion: { (result) in
                switch result {
                case .success(let upload, _, _):
                    
                    upload.uploadProgress(closure: { (Progress) in
                        
                    })
                    upload.responseJSON { response in
                        
                        if(response.result.isSuccess){
                            let datastring = NSString(data:response.data!, encoding:String.Encoding.utf8.rawValue) as String?
                            let serviceresponse = Mapper<ServiceResponseMessage>().map(JSONString: datastring!)
                            ServiceCallBack(datastring, serviceresponse!)
                        }else{
                            //                            print(response.result.error?.localizedDescription as Any)
                            let serviceReponse = ServiceResponseMessage()
                            HttpParameter.CurrentHttpCode = HttpCode.Error_503
                            serviceReponse?.IsSuccess = false
                            serviceReponse?.Message = (response.result.error?.localizedDescription)! as String
                            ServiceCallBack(nil, serviceReponse!)
                        }
                    }
                case .failure(let encodingError):
                    //self.delegate?.showFailAlert()
                    print(encodingError)
                }
            })
        } else {
            let serviceReponse = ServiceResponseMessage()
            HttpParameter.CurrentHttpCode = HttpCode.Error_504
            serviceReponse?.Code = HttpCode.Error_504.rawValue
            serviceReponse?.IsSuccess = false
            serviceReponse?.Message = AppMessage.NoInternetConnection
            ServiceCallBack(nil,serviceReponse!)
        }
    }
    
}


class JSONData {
    
    func onvertToDictionary(text: String) -> [String: Any]? {
        if let data = text.data(using: .utf8) {
            do {
                return try JSONSerialization.jsonObject(with: data, options: []) as? [String: Any]
            } catch {
                print(error.localizedDescription)
            }
        }
        return nil
    }
}
