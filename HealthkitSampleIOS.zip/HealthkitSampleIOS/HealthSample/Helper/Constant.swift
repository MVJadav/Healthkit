//
//  Constant.swift
//  iOSProject
//
//  Created by Kaira NewMac on 12/8/16.
//  Copyright © 2016 Kaira NewMac. All rights reserved.
//

import Foundation
import UIKit

let appDelegate = UIApplication.shared.delegate as! AppDelegate

struct AppConstant {

    static let AppName = "More Customers App" //Need Changes App name in LauchScreen Also
    static let SplashDescription = "We will help you to increase your business."
    static let Rs = "\u{20B9}"
    
    static let APIKey = "SiteAdminAppkey"
    static let AppSiteSlug = ""
    
    static let SiteContactNumber = "+91 7228881900"
}

struct FacebookAppData {
    static let AppSecret = "233bc4f9d173d848aeefcef50b6d34b8"
}

struct HttpParameter {
    
    ///MARK: - APIKey
    static let DeviceType = "IOS"
    static let Facebookid = "fb1455213297832894"
    
    static let ImagesType = "UserProfileImage"
    
    static let TimeOut = 60.0
    
    // MARK: - Constant
    static let HttpType_POST = "POST"
    static let HttpType_GET = "GET"
    
    // MARK: - Error Code
    static var CurrentHttpCode:HttpCode = HttpCode.Error_100
    
    //MARK:-Upload Image
    static let File = "file"
    static let Mimetype = "image/jpg"
    static let Filename = "team-icon.jpg"
    static let NotificationFilename = "user-notification.jpg"
    
    static let Error_500 = "500" //Oops something went wrong
    static let Error_410 = "410" //Token Expierd
    static let Error_400 = "400" //Error Message
    static let Error_401 = "401" //User Not Verify
    static let Error_200 = "200" //Succsessfull
    static let Error_203 = "203" //Succsessfull
    
    
    static let Platform = "I"
}

struct Links {
    static let appMessage = "Create FREE website & Share your products on Facebook & WhatsApp with few easy steps.\n"
    static let appVesrionMessage = "New version is available of \(AppConstant.AppName), download new version and access some new awesome features."
    static let rateusappstorelink = "https://itunes.apple.com/us/app/more-customers-app/id1280868223?ls=1&mt=8"
    static let gopro = "https://www.instamojo.com/kaira_software/more-customers-app-advance-amount/"
}

struct AppColor {

    //App Theme Status Bar
    static let Statusbar_Primary        = UIColor(red: 255/2552, green: 51/255, blue: 102/255, alpha: 0.7)
    
    //App Theme
    static let AppTheme_Primary         =  UIColor(red: 0/255, green: 144/255, blue: 255/255, alpha: 1.0)
    static let AppTheme_Secondary       = UIColor(red: 255/255, green: 51/255, blue: 102/255, alpha: 0.5)
    
    static let Dark_Pink_Secondary      = UIColor(red: 255/255, green: 51/255, blue: 102/255, alpha: 0.5)
    
    //General Light Color
    static let Light_Grey               = UIColor(red: 170/255, green: 170/255, blue: 170/255, alpha: 0.5)
    static let Light_Grey_Group         = UIColor(red: 207/255, green: 207/255, blue: 207/255, alpha: 0.8)
    static let Grey_Saperator           = UIColor(red: 203/255, green: 203/255, blue: 203/255, alpha: 1.0)
    
    //General Dark Color
    static let Dark_Pink                = UIColor(red: 255/255, green: 51/255, blue: 102/255, alpha: 1.0)
    static let Dark_Green               =  UIColor(red: 68/255, green: 175/255, blue: 86/255 , alpha :1.0)
    
//    static let Dark_Red         =  UIColor(red: 198/255, green: 26/255, blue: 22/255, alpha: 1.0)
    static let Dark_Orange              =  UIColor(red: 209/255, green: 92/255, blue: 50/255, alpha: 1.0)
    static let Dark_Gray                = UIColor(red: 67/255, green: 65/255, blue: 73/255 , alpha :1)
    
    static let Red                      = UIColor.red
    static let Green            = UIColor(red: 41/255, green: 169/255, blue: 88/255, alpha: 1.0)
    
//Activity Indicator color
    static let AppTheme_ActivityIndicator         =  UIColor(red: 255/255, green: 255/255, blue: 255/255, alpha: 0.5)
}

struct AppMessage {

    static let SyncFail                     = "App is not synced properly. Please retry."
    static let RequestFail                  = "Network error, please try after some time."
    static let NoInternetConnection         = "No internet connection found. Please restart app with internet connection."
    
    //Please login to add to Collection
    static let BeforeLogin                  = "Please login to add to Collection."
    //Security
    static let UserNameEmpty                = "User name required"
    static let ContactUsUserNameEmpty       = "Name required"
    
    static let mobileEmpty                  = "Mobile Number required"
    static let mobileError                  = "Invalid mobile number (i.e 0123456789)"
    
    static let emailEmpty                   = "Email required"
    static let emailError                   = "Invalid email address (i.e abc@mail.com)"
    
    static let descriptionEmpty             = "Message required"
    
    static let mailAccountNotFound          = "No email aoounnt found. Please provide your mail id with default mailbox."
    static let mailCancelled                = "Rate us mail cancelled"
    static let mailSave                     = "Rate us mail saved to draft"
    static let mailSent                     = "Mail sent successfully"
    static let mailError                    = "Please try again later, mail not sent"
    
    static let WhatsAppError                = "Please, install whatsaap first"
    
    static let LoginSuccessfull             = "Login Successfull"
    static let Logout                       = "Logout"
    static let LoginTryAgain                = "Please try again!"
    
    static let AddLogoUploadeEmpty          = "Please add logo image"
    static let UploadeEmptyImage            = "Please add image"
    
    static let OTPSent                      = "OTP sent successfull"
    
    static let AddToWishList                = "Added to Wishlist"
    static let CommingSoon                  = "Comming Soon"
    static let RemoveFromWishList           = "Removed from Wishlist"
    
    static let NoProductFound               = "No Product Found"
    static let SelectProduct                = "Please select one product."
    
    static let Required_Category            = "Please select at least one subcategory"
    static let Required_SubAttribute        = "Please select at least one subattribute"
    static let AddCategory                  = "Please add Category first"
    
    static let ActivateCategory             = "This category is currently deactivated, click on the Active button to active this category. Once you Activate this category then this will appear in the website and application."
    static let DeActivateCategory           = "Click on the Deactivate button to disable this category from the website and application. Once you deactivate this category then this will disappear from the website and application."
    
    static let ActivateSubCategory          = "This category is currently deactivated, click on the Active button to active this subcategory. Once you Activate this subcategory then this will appear in the website and application."
    static let DeActivateSubCategory        = "Click on the Deactivate button to disable this subcategory from the website and application. Once you deactivate this subcategory then this will disappear from the website and application."
    
    static let AddPostLogo                  = "Please upload logo first"
 
    //CompleteSetup Add Category
    static let CompleteSetup_Category       = "Add the Menu name this will be shown your site as Menu. Example you are running readymade store you can create menu for Men or Women etc."
    
    
    //Owner Phone Number
    static let ContactInfoRequired          = "Please add atleast one Contact information"
    
    //Subscriber
    static let DeleteSubscriberContact      = "This contact will be deleted from list."
    static let AddSubscriberContact         = "This contact will be added in your phonebook and you can send him Whatsapp updates."
    
    static let RemoveShopImage              = "Are you sure you want to remove this Image?"
    
    static let ShopImageLimit               = "Limit exceeded, you cannot add more than 15 Images"
    
    static let ProductAddSuccess            = "Product Added Successfully."
    
    //delete post
    static let postDeleteWarning                = "Are you sure you want to delete this Post?"
    
    // logout user
    static let userLogout                   = "Are you sure you want to logout?"
}

struct ValidationMessage {
    
    static let userNameEmpty                = "Username required"
    static let passwordEmpty                = "Password required"
    static let passwordInvalid              = "Invalid passowd"
    
    static let emailEmpty                   = "Email required"
    static let mobileEmpty                  = "Mobile number required"
    
    static let emailError                   = "Invalid Email Address (i.e abcd@xyz.com)"
    static let nameError                    = "Invalid name"
    static let firstNameError               = "Invalid Firstname"
    static let lastNameError                = "Invalid Lastname"
    static let passwordError                = "Password must be at least 6 character"
    static let mobileError                  = "Mobile number must be 10 digits"
    static let mobileInvalid                = "Invalid Mobile No."
    
    static let postPriceError               = "Invalid Price (i.e 10000)"
    static let productNameEmpty             = "Product name required"
    static let productNameError             = "Invalid product name"
    
    static let productPrice1Empty           = "Price1 required"
    static let productPrice1Error           = "Invalid Price1"
    
    static let productPrice2Error           = "Invalid Price1"
    static let productStrikePrice1Error     = "Invalid Strike Price1"
    static let productStrikePrice2Error     = "Invalid Strike Price2"
    
    static let productStrikePrice1ValError  = "StrikePrice 1 must be higher than Price 1"
    static let productStrikePrice2ValError  = "StrikePrice 2 must be higher than Price 2"
    
    static let productSlugEmpty             = "Slug required"
    static let productSlugError             = "Invalid slug"
    static let productShortDescEmpty        = "Short Description required"
    static let productLongDescEmpty         = "Long Description required"
    
    //Setup Message
    static let CompleteStepError            = "Please complete all the steps first to build your website."
    
    //Create Business Validation Message
    static let BusinessName                 = "Business Name required"
    static let BusinessAddress              = "Business Address required"
    static let BusinessCity                 = "Business City required"
    static let SelectState                  = "Select State"
    static let SelectColor                  = "Select Colour"
    static let BusinessState                = "Business State required"
    static let BusinessPostalCodeEmpty      = "Postal Code required"
    static let BusinessPostalCode           = "Postal Code must be 6 digits"
    static let BusinessURL                  = "Please enter valid URL"
    
    static let ProductDescriptionEmpty      = "Description required"
    
    
    //Selling Mode
    static let Selling_PaymentOption        = "Please Select Atleast one Payment Option"
    
    //Contact Added
    static let ContactAdde                  = "This contact is added in your phonebook."
    static let ContactAddeError             = "Please try again !"
    static let AlreadyExistContact          = "Contact is already saved into your phonebook."
    
    //ColorCode
    static let ColorCode           = "Color Code must be AlphaNumeric"
    
}

struct VariablesMessage {
    
    static let ShortDescription             = "Write short description about your product specialty"
    static let LongDescription              = "Write long description about your product specialty"
    static let MetaDescription              = "Write meta description about your product specialty"
    static let ProductDescription           = "Product Description"
    static let BusinessDescription          = "Write something about business"
    static let PostTitle                    = "Post title"
}

//MARK: Place Holder Text
struct PlaceHolderText {
    
    static let ShopTimingDescription        = "SHOP TIMINGS"
    
}

//MARK: FeedBack Header title

struct FeedbackHeaderMessage {
    
    static let Suggestion                   = "Enter your suggestions"
    static let SuggestionDescription        = "Write message here"
    
    static let Issue                        = "Enter your Issue"
    static let IssueDescription             = "Write issue here"
    
    static let EnquiryRpl                   = "Enter your message"
    static let EnquiryRplDescription        = "Write message here"
    
    static let Comments                     = "Comments"
    static let CommentDescription           = "Write Comments here"
}

struct GeneralFeedbackMessageTitle {
    
    static let SubTitle_Login           = "If you are facing any problem. Please provide your name and mobile number. Our representative will contact you soon."
    
    static let SubTitle_GoPro           = "Please add ypur Name and Mobile number, Our sales person will contact you soon."
}

struct ButtonTitle {
    
    //Button Title
    static let btnRetry = "Retry"
    static let btnOk = "OK"
    static let btnDelete = "Delete"
    static let btnCancel = "Cancel"
}

struct AlertTitle {
    
    //Error Title
    static let Error                        = "Error"
    static let Warning                      = "Warning"
    static let Success                      = "Success"
    static let DeleteCategory               = "Delete Category"
    static let DeleteSubCategory            = "Delete SubCategory"
    static let AddSubscriber                = "Add Subscriber"
}

struct AlertSubTitle {
    
    static let DeleteCategory               = "Are you sure you want to delete this category?"
    static let DeleteSubCategory            = "Are you sure you want to delete this subcategory?"
}

struct Unicode {
    
    static let UserName = "\u{f072}"
    static let Password = "\u{f023}"
}

struct RegularExpression {
    /*
     // MARK: - Set RequireField Alert
     */
    let REGEX_USER_NAME_LIMIT               = "^.{3,10}$"
    let REGEX_USER_NAME                     = "^.{1,50}"
    static let REGEX_EMAIL                  = "[A-Z0-9a-z._%+-]{3,}+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}"
    
    static let REGEX_PASSWORD_LIMIT         = "^.{6,25}$"
    static let REGEX_PASSWORD               = "[A-Za-z0-9]{6,20}"
    static let REGEX_PHONE_DEFAULT          = "[0-9]{3}\\-[0-9]{3}\\-[0-9]{4}"
    static let REGEX_PHONE_NUMBER           = "[0-9]{15}"
    static let REGEX_Mobile_NUMBER          = "[0-9+]{10,15}"
    static let REGEX_COLORCODE              = "[A-Za-z0-9]{6}"
    static let REGEX_ZipCode                = "[0-9]{6}"
    static let REGEX_OTP                    = "[0-9]{6}"
    static let REGEX_Name                   = "[A-Za-z]{1,20}"
    static let REGEX_Domain                 = "[A-Za-z0-9.]{1,50}"
    static let REGEX_UserName               = "[A-Za-z0-9. ]{1,50}"
    static let REGEX_PRODUCT_NAME           = "^.{1,150}"
    static let REGEX_FirmName               = "[A-Za-z]{20}"
    static let REGEX_PromoCode              = "[A-Za-z0-9]{1,10}"
    static let REGEX_Location               = "^.{1,150}"
    
    //static let REGEX_PRICE             = "^[0-9]+(?:\\.[0-9]{1,10})?$"
    static let REGEX_PRICE                  = "[0-9]{1,10}"
    static let REGEX_URL                    = "(http|https)://((\\w)*|([0-9]*)|([-|_])*)+([\\.|/]((\\w)*|([0-9]*)|([-|_])*))+"
}

struct TabbarTitle {
    
    static let Articles                 = "Learn Acticle"
    static let Act                      = "Act"
    
    static let Dashboard                = "Dashboard"
    static let Products                 = "Products"
    static let Enquire                  = "Enquiries"
    static let Post                     = "Post"
    static let Settings                 = "Settings"
    static let More                     = "More"
    static let GoPRO                    = "Go PRO"
    static let PostList                 = "Post List"
    static let CustomerList             = "Customer List"
    
    
    static let Notification             = "Notification"
    
    static let Aboutus                  = "About Us"
    static let Filter                   = "Filter"
    
    
    static let Business                 = "Add Your Business"
    static let BusinessAdd              = "Register Business"
    static let ForgotPassword           = "Forgot Password"
    static let ConfirmPassword          = "Change Password"
    static let SignUp                   = "Sign Up"
    static let OTPVerify                = "Verify OTP"
    static let Profile                  = "Profile"
    static let CompleteSetup            = "Complete Setup"
    static let CoverPhotos              = "Cover Photos"
    static let WebSiteSetup             = "Website Setup"
    static let ColorPicker             = "Choose Website Color"
    
    static let Header                   = "Website Labels"
    
    static let Category                 = "Category"
    static let AddCategory              = "Add Category"
    static let AddCompleteSetupCategory = "Add Menu"
    static let AddSubCategory           = "Add SubCategory"
    static let EditCategory             = "Edit Category"
    static let Logo                     = "Logo"
    static let LogoOption               = "Logo Option"
    
    static let Product                  = "Product"
    static let AddProduct               = "Add new product"
    static let EditProduct              = "Update product"
    static let BusinessDetail           = "Business Detail"
    
    static let SocialAccount            = "Social Account Links"
    static let ConnectSocialAccount     = "Connect Social Accounts"
    static let ShopTiming               = "Shop Timings"
    static let ShopPhotos               = "Shop Photos"
    static let PhoneNumber              = "Phone Numbers"
    static let SellingMode              = "Enable Online Selling"
    
    static let ContactUS               = "Contact Us"
    
    static let Subscribe               = "WhatsApp Subscribers"
    
    //POSTs
    static let AddPost              = "Add Post"
    static let EditPost              = "Edit Post"
    static let EditPostImage              = "Edit Image"
    
    //Orders
    static let OrderList               = "Orders"
    static let OrderDetails               = "Order Details"
    
    //Share Post
    
    static let PostShare                = "Post Share"
    static let FacebookPages            = "Facebook Pages"
}
//"Terms & Conditions"
struct NavigationBarTitle {
    
    static let TermsandCondition = "Terms & Conditions"
    static let Aboutus = "About Us"
}

struct TabbarImage {
    
    static let Home_unselect            = "ic_tab_home_unselect"
    static let Product_unselect         = "ic_tab_product_unselect"
    static let Post_unselected          = "ic_tab_post_unselect"
    static let Enquiry_unselect         = "ic_tab_enquiry_unselect"
    static let Settings_unselect        = "ic_tab_setting_unselect"
    static let More_unselect            = "ic_tab_more_unselect"
    static let Notification_unselect    = "ic_tab_notification_unselect"
    
    
    static let Home_select            = "ic_tab_home_select"
    static let Product_select         = "ic_tab_product_select"
    static let Post_selected          = "ic_tab_post_select"
    static let Enquiry_select         = "ic_tab_enquiry_select"
    static let Settings_select        = "ic_tab_setting_select"
    static let More_select            = "ic_tab_more_select"
    static let Notification_select    = "ic_tab_notification_selected"
}

struct SiteImageName {
    
    static let SectionBanner1           = "SectionBanner1"
    static let SectionBanner2           = "SectionBanner2"
    static let Gallery                  = "Gallery"
    
    static let Slider                   = "Slider"
    static let LogoImage                = "LogoImage"
    static let Slider1                  = "Slider1"
    static let Slider2                  = "Slider2"
    static let Slider3                  = "Slider3"
    static let Slider4                  = "Slider4"
    static let AboutusBanner            = "AboutusBanner"
    static let AboutusCompanylogo       = "AboutusCompanylogo"
    static let VisitorStoreBanner       = "VisitorStoreBanner"
    static let VisitorStoreLogo         = "VisitorStoreLogo"
    static let ContactUsBanner          = "ContactUsBanner"
    static let WishListBanner           = "WishListBanner"
    static let TermsCondition           = "TermsCondition"
    static let EnquiryBanner            = "EnquiryBanner"
}

struct SiteLabelsName {
    
    static let CurrencySymbol               = "CurrencySymbol"
    static let HomeLabel1                   = "HomeLabel1"
    static let HomeLabel2                   = "HomeLabel2"
    static let HomeLabel3                   = "HomeLabel3"
    static let HomeLabel4                   = "HomeLabel4"
    static let ContactUsLabel12             = "ContactUsLabel12"
    static let FooterDescriptionLabel2      = "FooterDescriptionLabel2"
    static let ContactUsPhoneDisplayLabel   = "ContactUsPhoneDisplayLabel"
    static let ContactUsEmailIDLabel        = "ContactUsEmailIDLabel"
}

struct AppVariable {
    
    static let Img_Placeholder = "ic_Test"
    static let Img_CategorySelect = "ic_CategorySelect"
    static let OTPCodeTimer = 60
    
}

class SettingsScreenList {
    
    static let ScreenString = "{\"Data\":[{\"SettingsModel\":[{\"ID\":0,\"Name\":\"Business Details\",\"ImagePath\":\"ic_settings_bdetail\"},{\"ID\":1,\"Name\":\"Phone Numbers\",\"ImagePath\":\"ic_settings_Phone\"},{\"ID\":2,\"Name\":\"Shop Photos\",\"ImagePath\":\"ic_shop_image\"},{\"ID\":3,\"Name\":\"Shop Timings\",\"ImagePath\":\"ic_settings_shop\"}],\"SettingsId\":0,\"SettingName\":\"FIRM\"},{\"SettingsModel\":[{\"ID\":0,\"Name\":\"Logo\",\"ImagePath\":\"ic_settings_logooption\"},{\"ID\":1,\"Name\":\"Cover Photos\",\"ImagePath\":\"ic_settings_cover\"},{\"ID\":2,\"Name\":\"Social Account Links\",\"ImagePath\":\"ic_social_account\"},{\"ID\":3,\"Name\":\"First Color\",\"ImagePath\":\"ic_settings_color_first\"},{\"ID\":4,\"Name\":\"Second Color\",\"ImagePath\":\"ic_settings_color_second\"},{\"ID\":5,\"Name\":\"Third Color\",\"ImagePath\":\"ic_settings_color_third\"},{\"ID\":6,\"Name\":\"Website Fonts\",\"ImagePath\":\"ic_font_style\"},{\"ID\":7,\"Name\":\"Website Labels\",\"ImagePath\":\"ic_header\"},{\"ID\":8,\"Name\":\"Enable Online Selling\",\"ImagePath\":\"ic_action_selling_mode\"}],\"SettingsId\":1,\"SettingName\":\"SITE/ APP\"},{\"SettingsModel\":[{\"ID\":0,\"Name\":\"Category\",\"ImagePath\":\"ic_settings_category\"}],\"SettingsId\":2,\"SettingName\":\"CATEGORY\"},{\"SettingsModel\":[{\"ID\":0,\"Name\":\"Connect Social Accounts\",\"ImagePath\":\"ic_social_account\"}],\"SettingsId\":3,\"SettingName\":\"3RD PARTY INTEGRATION\"}]}"
}

class MoreVCScreenList {
    
    static let ScreenString = "{\"Data\":[{\"SettingsModel\":[{\"ID\":0,\"Name\":\"Enquiries\",\"ImagePath\":\"ic_enquiry\"},{\"ID\":1,\"Name\":\"Orders\",\"ImagePath\":\"ic_orders\"},{\"ID\":2,\"Name\":\"Customers List\",\"ImagePath\":\"ic_customerlist\"},{\"ID\":3,\"Name\":\"WhatsApp Susbscribers\",\"ImagePath\":\"ic_subscriber\"},{\"ID\":4,\"Name\":\"Settings\",\"ImagePath\":\"ic_setting\"}],\"SettingsId\":0,\"SettingName\":\"Important\"},{\"SettingsModel\":[{\"ID\":0,\"Name\":\"Go PRO\",\"ImagePath\":\"ic_go_pro\"},{\"ID\":1,\"Name\":\"Contact Us\",\"ImagePath\":\"ic_nav_contactus\"},{\"ID\":2,\"Name\":\"Rate Us\",\"ImagePath\":\"ic_action_rate_us\"},{\"ID\":3,\"Name\":\"Like Us on Facebook\",\"ImagePath\":\"ic_FBlike\"},{\"ID\":4,\"Name\":\"Share App\",\"ImagePath\":\"ic_more_share\"}],\"SettingsId\":1,\"SettingName\":\"Reach Us\"},{\"SettingsModel\":[{\"ID\":0,\"Name\":\"Logout\",\"ImagePath\":\"ic_logout\"}],\"SettingsId\":2,\"SettingName\":\"Logout\"}]}"
    
}

class DashbouardVCList {
    
    static let ScreenString = "{\"Data\":[{\"ID\":0,\"Name\":\"ORDERS\",\"ImagePath\":\"ic_dash_order\",\"Color\":\"ECBB98\"},{\"ID\":1,\"Name\":\"ENQUIRIES\",\"ImagePath\":\"ic_dash_enquiry\",\"Color\":\"F4DD8E\"},{\"ID\":2,\"Name\":\"SUBSCRIBERS\",\"ImagePath\":\"ic_dash_whatsapp\",\"Color\":\"B1E58B\"},{\"ID\":3,\"Name\":\"POST VIEW\",\"ImagePath\":\"ic_dash_post\",\"Color\":\"101010\"},{\"ID\":4,\"Name\":\"PRODUCT VIEW\",\"ImagePath\":\"ic_dash_product\",\"Color\":\"101010\"}]}"
}
struct DashboardListID {

    static let OrdersCount          = 0
    static let InquiriesCount       = 1
    static let SubscribersCount     = 2
    static let PostView             = 3
    static let ProductView          = 4
}

// MARK: Date Time Formate
struct DateTimeFormate {
    
    static let Formate_yyyyMMddTHHmmssZ = "yyyy-MM-dd\'T\'HH:mm:ss Z"
    
    static let Formate_yyyyMMddHHmmssZ = "yyyy-MM-dd\' \'HH:mm:ss Z"
    
    static let Formate_yyyyMMdd = "yyyy-MM-dd"
    
    static let Formate_yyyyMMddhhmmaa = "yyyy-MM-dd hh:mm aa"
    
    static let Formate_EEEdMMMyyyyathhmmaa = "EEE d MMM, yyyy 'at' hh:mm aa"
    
    static let Formate_EEEdMMMathhmma = "EEE d MMM 'at' hh:mm a"
    
    static let Formate_MMMdathhmma = "MMM d 'at' hh:mm a"
    
    static let Formate_ddMMMathhmma = "dd MMM' at' hh:mm a"
    
    static let Formate_hhmma = "hh:mm a"
    
    static let Formate_ddMMyyyyHHmmssZZZ = "dd-MM-yyyy HH:mm:ss ZZZ"
    
    static let Formate_ddMMMyyyyathhmma = "dd MMM, yyyy 'at' hh:mm a"
    
    static let Formate_yyyy = "yyyy"
    
    static let Formate_HHmmss = "HH:mm:ss"
    
    static let Formate_ddMMM = "dd MMM"
    
    static let Formate_hhmmaddMMMyyyy = "hh:mm a dd MMM, yyyy"
    
    static let Formate_ddMMMyyyy = "dd MMM, yyyy"
    
    static let Formate_ddMMMWithoutCommayyyy = "dd MMM yyyy"
    
    static let Formate_ddMMyyyyhhmma = "dd/MM/yyyy hh:mm a"
    
}

struct Sort {
    
    static let Asc                      = "ASC"
    static let Desc                     = "DESC"
    static let ProductNameAsc           = -1
    static let PriceLowToHigh           = 0
    static let PriceHighToLow           = 1
    static let MostVisited              = 2
    static let Newest                   = 3
    static let Featured                 = 4
}

struct SortExpresion {
    static let ViewCount        = "ViewCount"
    static let ProductID        = "ProductID"
    static let Price            = "Price"
    static let CreatedDate      = "CreatedDate"
    static let ProductName      = "ProductName"
}

struct EnquirySortOption {
    //All= -1,Read=1,UnRead=0(Default) IsRead
    static let All : Int        = -1
    static let Read : Int       = 1
    static let UnRead : Int     = 0
}

struct ProductStatus {
    //All= -1,Read=1,UnRead=0(Default) IsRead
    static let All : Int            = -1
    static let Active : Int         = 1
    static let InActive : Int       = 0
}

struct AppFont {
    //UIFont(name: "HelveticaNeue-Medium", size: 13.0)
    //Helvetica Neue Light 14.0
    static let HelveticaNeueMedium_13      = UIFont(name: "HelveticaNeue-Medium", size: 13.0)
    static let HelveticaNeue_13            = UIFont(name: "HelveticaNeue", size: 13.0)
    static let HelveticaNeue_12         = UIFont(name: "HelveticaNeue", size: 12.0)
    static let HelveticaNeue_14         = UIFont(name: "HelveticaNeue", size: 14.0)
    static let HelveticaNeue_16         = UIFont(name: "HelveticaNeue", size: 21.0)
    static let HelveticaNeueLight       = UIFont(name: "HelveticaNeue-Light", size: 14.0)
    
    static let HelveticaNeueBold_16     = UIFont(name: "HelveticaNeue-Bold", size: 16.0)
    static let HelveticaNeueBold_14     = UIFont(name: "HelveticaNeue-Bold", size: 14.0)
    
}

struct AppImageName {
    
    static let Img_Placeholder          = "ic_Test"
    static let Img_Placeholder_Logo          = "AppLogo"//
    static let Img_Placeholder_Post     = "ic_Placeholder_Post"
    static let Img_CategorySelect       = "ic_CategorySelect"
    static let Img_PlaceholderBanner    = "ic_PlaceholderBanner"
    static let Img_Call = "ic_call"
    static let Img_Plus_100 = "ic_plus_100"
    
    static let Img_FloatingProduct = "ic_floating_product"
    static let Img_FloatingPost = "ic_floating_post"
}

struct ProductDelete {

    static let OkButton             = "Ok"
    static let CancelButton         = "Cancel"
    static let AlertTitle           = "Delete Product"
    static let AlertSubTitle        = "Are you sure you want to delete the product?"
    
}

struct SocialButtonName {
    
    static let OkButton             = "Ok"
    static let CancelButton         = "Cancel"
    static let NotNow               = "NOT NOW"
    static let Update               = "GO PRO"
    
    static let AlertTitle           = "MoreCustomersApp"
    static let AlertSubTitle        = "To share your product please upgrade your Subscription plan."
    
}

struct ProductActive {
    static let All              = "All"
    static let Active           = "Active"
    static let InActive         = "Deactive"
}

struct Featured {
    static let All                  = "All"
    static let Featured             = "Featured"
    static let NotFeatured          = "Not Featured"
}

struct CompleteSetup {
    
    static let FirstColor               = "@primary_color"
    static let SecondColor              = "@secondary_color"
    static let ThirdColor               = "@third_color"
}


struct RedirectionType{
    
    static let Default                  =  0                      //if type 1
    static let NewArrival               =  1                      //if type 2
    static let Offers                   =  2                      //if type 2
    static let Category                 =  3                      //if type 3
    static let Other                    =  4                      //if type 4
    
    
    static let DefaultTxt               = "Select Redirect URL"
    static let HomeTxt                  = "Home"
    static let OtherTxt                 = "Other"

}

//MARK: permition Message
struct PermitionMessage {
    static let albumTitle = "Allow photo album access?"
    static let albumMessage = "Need your permission to access photo albumbs"
    static let cameraTitle = "Allow camera album access?"
    static let cameraMessage = "Need your permission to take a photo"
    static let bLockPost = "Are you sure you want to block this user?"
    static let deletePost = "Are you sure you want to delete this post?"
    
}



struct RemainigStepsIds {
    
    static let IsBusinessDescriptionAdded   =  101
    static let IsLogo                       =  102
    static let IsPrimaryColor               =  103
    static let IsCoverPhoto                 =  104
    static let IsPost                       =  105
    static let IsProduct                    =  106

}

//struct DashboardListID {
//    
//    
//    static let OrdersCount          = 0
//    static let InquiriesCount       = 1
//    static let SubscribersCount     = 2
//    static let PostView             = 3
//    static let ProductView          = 4
//}

struct DocumentsDirectory {
    static let ducumentDireName = "MCA"
}

struct FileExtention {
    
    static let PNG = "png"
    static let JPEG = "jpeg"
    
}


struct NotificationType {
    static let  Subscribers : Int    = 5
    static let  Enquiry    : Int         = 6
    static let  Daily           : Int    = 7
    static let  SignUp           : Int   = 8
}



