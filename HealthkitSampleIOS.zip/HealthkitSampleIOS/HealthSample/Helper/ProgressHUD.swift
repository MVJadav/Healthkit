//
//  ProgressHUD.swift
//  iOSProject
//
//  Created by Kaira NewMac on 12/9/16.
//  Copyright © 2016 Kaira NewMac. All rights reserved.
//

import UIKit

class ProgressHUD: NSObject {
    
    class func startLoading(onView view:UIView){
        stopLoading(fromView: view)
        let activity = UIActivityIndicatorView(activityIndicatorStyle: UIActivityIndicatorViewStyle.gray)
        view.addSubview(activity)
        
        activity.translatesAutoresizingMaskIntoConstraints = false
        
        view.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "H:|-(leadingTrailing)-[activity]-(leadingTrailing)-|", options: NSLayoutFormatOptions(rawValue: 0), metrics: ["leadingTrailing":-8], views: ["activity":activity]))
        
        view.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "V:|-(leadingTrailing)-[activity]-(leadingTrailing)-|", options: NSLayoutFormatOptions(rawValue: 0), metrics: ["leadingTrailing":-8], views: ["activity":activity]))
        
        activity.backgroundColor = UIColor.white.withAlphaComponent(0.3)
        activity.startAnimating()
        
        UIApplication.shared.isNetworkActivityIndicatorVisible = true
    }
    
    class func stopLoading(fromView view:UIView){
        for subView in view.subviews{
            if subView.isKind(of: UIActivityIndicatorView.self){
                (subView as! UIActivityIndicatorView).stopAnimating()
                (subView as! UIActivityIndicatorView).removeFromSuperview()
                
                UIApplication.shared.isNetworkActivityIndicatorVisible = false
            }
        }
    }

}
