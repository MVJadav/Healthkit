//
//  serviceURL.swift
//  iOSProject
//
//  Created by Kaira NewMac on 12/8/16.
//  Copyright © 2016 Kaira NewMac. All rights reserved.
//

import Foundation


class ServiceUrl {
    
    /************************Local Base URL******************************/
    
    static let Domain = "http://192.168.1.126:8081/"           //admin
    static let Base = Domain+"FitnessApp/"
    /************************ Othe URL ******************************/
    
    
    static let StoreInfoURL = "http://itunes.apple.com/lookup?bundleId=com.kaira.MoreCustomersApp"
    
    /************************Service URL******************************/
    //LookUp Service
    
    //Securiry
    static let Login                        = Base + "trunk/postuserdata"
    static let HealthActivity               = Base + "trunk/postuserhealthactivity"
    
}
