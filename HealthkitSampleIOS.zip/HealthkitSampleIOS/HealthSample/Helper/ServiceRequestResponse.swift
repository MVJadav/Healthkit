//
//  ServiceRequestResponse.swift
//  iOSProject
//
//  Created by Kaira NewMac on 12/12/16.
//  Copyright © 2016 Kaira NewMac. All rights reserved.
//

import UIKit
import Foundation
import Alamofire
import ObjectMapper


class ServiceRequestResponse: NSObject {
    
    class func servicecall(IsLoader:Bool? = true, url: String, HttpMethod: HTTPMethod, InputParameter: Parameters, viewController:UIViewController? = nil, ServiceCallBack: @escaping (_ result: String?, _ IsSuccess: Bool?)-> Void) {
    
        
        
        if IsLoader == true {
            if viewController != nil {
                ProgressHUD.startLoading(onView: (viewController?.view)!)
            } else {
                ProgressHUD.startLoading(onView: appDelegate.window!)
            }
        }
        HttpRequest.serviceResponse(url: url, HttpMethod: HttpMethod, InputParameter: InputParameter) { (result, response) -> Void in
            
            if IsLoader == true {
                if viewController != nil {
                    ProgressHUD.stopLoading(fromView: (viewController?.view)!)
                } else {
                    ProgressHUD.stopLoading(fromView: appDelegate.window!)
                }
            }
            
            print("URL: ",url)
            print("Request: ",InputParameter)
            if let strResult = result {
                
                let jsonDictionary:NSDictionary = convertToDictionary(text: strResult)!
                print("Response: ",jsonDictionary)
            }
            if response.IsSuccess == true {
                
                ServiceCallBack(result, true)
            }
            else {
                
                switch response.Code {
                
                case HttpCode.Error_500.rawValue?:
                    HttpParameter.CurrentHttpCode = HttpCode.Error_500
                    //Oops something went wrong
                    ServiceCallBack(nil, false)
                    if let strMessage = response.Message {
                        
                        _ = SCLAlertView().showError(AlertTitle.Error, subTitle:strMessage, closeButtonTitle:ButtonTitle.btnOk)
                    }
                    break
                    
                case HttpCode.Error_503.rawValue?:
                    HttpParameter.CurrentHttpCode = HttpCode.Error_503
                    //Http Request Failur
                    ServiceCallBack(nil, false)
                    if let strMessage = response.Message {
                        _ = SCLAlertView().showError(AlertTitle.Error, subTitle:strMessage, closeButtonTitle:ButtonTitle.btnOk)
                    }
                    
                    break
                    
                case HttpCode.Error_504.rawValue?:
                    HttpParameter.CurrentHttpCode = HttpCode.Error_504
                    //ServiceCallBack(nil, false)
                    
                    NoInternetVC.showNoInternetVC(completion: { (completionHandler) in
                        switch completionHandler {
                        case .Retry:
                                self.servicecall(url: url, HttpMethod: HttpMethod, InputParameter: InputParameter, viewController:viewController, ServiceCallBack: ServiceCallBack)
                                break
                        default: break
                        }
                    })
                    break
                    
                case HttpCode.Error_410.rawValue?:
                    HttpParameter.CurrentHttpCode = HttpCode.Error_410
                    //Token Expierd
                    ServiceCallBack(nil, false)
                    Preference.prefrenceClear()
//                    FBHelper.logout()
                    let objLoginVC = UserProfile(nibName: "UserProfile", bundle: nil)
                    let navigationController = UINavigationController(rootViewController: objLoginVC)
                    appDelegate.window?.rootViewController = navigationController
                    appDelegate.window?.makeKeyAndVisible()

                    if let strMessage = response.Message {
                        
                        _ = SCLAlertView().showError(AlertTitle.Error, subTitle:strMessage, closeButtonTitle:ButtonTitle.btnOk)
                    }
                    break
                    
                case  HttpCode.Error_401.rawValue?:
                    HttpParameter.CurrentHttpCode = HttpCode.Error_401
                    //User Not Verify
                    ServiceCallBack(nil, false)
                    if let strMessage = response.Message {
                        _ = SCLAlertView().showError(AlertTitle.Error, subTitle:strMessage, closeButtonTitle:ButtonTitle.btnOk)
                    }
                    break
                    
                case  HttpCode.Error_400.rawValue?:
                    HttpParameter.CurrentHttpCode = HttpCode.Error_400
                    //Error Message
                    ServiceCallBack(nil, false)
                    break
                    
                default:
                    HttpParameter.CurrentHttpCode = HttpCode.Error_100
                    ServiceCallBack(nil, false)
                    if let strMessage = response.Message {
                        _ = SCLAlertView().showError(AlertTitle.Error, subTitle:strMessage, closeButtonTitle:ButtonTitle.btnOk)
                    }
                }

            }
        }
    }
    
    // PHP Service Call 
    
    class func servicecallPHP(IsLoader:Bool? = true, url: String, HttpMethod: HTTPMethod, InputParameter: Parameters, viewController:UIViewController? = nil, ServiceCallBack: @escaping (_ result: String?, _ IsSuccess: Bool?)-> Void) {
        
        
        
        if IsLoader == true {
            if viewController != nil {
                ProgressHUD.startLoading(onView: (viewController?.view)!)
            } else {
                ProgressHUD.startLoading(onView: appDelegate.window!)
            }
        }
        HttpRequest.serviceResponsePHP(url: url, HttpMethod: HttpMethod, InputParameter: InputParameter) { (result, response) -> Void in
            
            if IsLoader == true {
                if viewController != nil {
                    ProgressHUD.stopLoading(fromView: (viewController?.view)!)
                } else {
                    ProgressHUD.stopLoading(fromView: appDelegate.window!)
                }
            }
            
            print("URL: ",url)
            print("Request: ",InputParameter)
            if let strResult = result {
                
                let jsonDictionary:NSDictionary = convertToDictionary(text: strResult)!
                print("Response: ",jsonDictionary)
            }
            if response.IsSuccess == true {
                
                ServiceCallBack(result, true)
            }
            else {
                
                switch response.Code {
                    
                case HttpCode.Error_500.rawValue?:
                    HttpParameter.CurrentHttpCode = HttpCode.Error_500
                    //Oops something went wrong
                    ServiceCallBack(nil, false)
                    if let strMessage = response.Message {
                        _ = SCLAlertView().showError(AlertTitle.Error, subTitle:strMessage, closeButtonTitle:ButtonTitle.btnOk)
                    }
                    break
                    
                case HttpCode.Error_503.rawValue?:
                    HttpParameter.CurrentHttpCode = HttpCode.Error_503
                    //Http Request Failur
                    ServiceCallBack(nil, false)
                    if let strMessage = response.Message {
                        _ = SCLAlertView().showError(AlertTitle.Error, subTitle:strMessage, closeButtonTitle:ButtonTitle.btnOk)
                    }
                    
                    break
                    
                case HttpCode.Error_504.rawValue?:
                    HttpParameter.CurrentHttpCode = HttpCode.Error_504
                    //ServiceCallBack(nil, false)
                    
                    NoInternetVC.showNoInternetVC(completion: { (completionHandler) in
                        switch completionHandler {
                        case .Retry:
                            self.servicecall(url: url, HttpMethod: HttpMethod, InputParameter: InputParameter, viewController:viewController, ServiceCallBack: ServiceCallBack)
                            break
                        default: break
                        }
                    })
                    break
                    
                case HttpCode.Error_410.rawValue?:
                    HttpParameter.CurrentHttpCode = HttpCode.Error_410
                    //Token Expierd
                    ServiceCallBack(nil, false)
                    if let strMessage = response.Message {
                        _ = SCLAlertView().showError(AlertTitle.Error, subTitle:strMessage, closeButtonTitle:ButtonTitle.btnOk)
                    }
                    break
                    
                case  HttpCode.Error_401.rawValue?:
                    HttpParameter.CurrentHttpCode = HttpCode.Error_401
                    //User Not Verify
                    ServiceCallBack(nil, false)
                    if let strMessage = response.Message {
                        _ = SCLAlertView().showError(AlertTitle.Error, subTitle:strMessage, closeButtonTitle:ButtonTitle.btnOk)
                    }
                    break
                    
                case  HttpCode.Error_400.rawValue?:
                    HttpParameter.CurrentHttpCode = HttpCode.Error_400
                    //Error Message
                    ServiceCallBack(nil, false)
                    break
                    
                default:
                    HttpParameter.CurrentHttpCode = HttpCode.Error_100
                    ServiceCallBack(nil, false)
                    if let strMessage = response.Message {
                        _ = SCLAlertView().showError(AlertTitle.Error, subTitle:strMessage, closeButtonTitle:ButtonTitle.btnOk)
                    }
                }
                
            }
        }
    }
    
    
    // Single Image Upload
    class func servicecallImageUpload(IsLoader:Bool? = true, imageDataFile: Data? = nil, url: String, HttpMethod: HTTPMethod, InputParameter: [String:String]? = nil , viewController:UIViewController? = nil, ServiceCallBack: @escaping (_ result: String?, _ IsSuccess: Bool?)-> Void) {
        
        if IsLoader == true {
            if viewController != nil {
                ProgressHUD.startLoading(onView: (viewController?.view)!)
            } else {
                ProgressHUD.startLoading(onView: appDelegate.window!)
            }
        }
        // InputParameter as? [String:String]
        
        
        HttpRequest().serviceCallImageUpload(imageData: imageDataFile,url: url, HttpMethod: HttpMethod, parameter: InputParameter ) { (result, response) -> Void in
       
            if IsLoader == true {
                if viewController != nil {
                    ProgressHUD.stopLoading(fromView: (viewController?.view)!)
                } else {
                    ProgressHUD.stopLoading(fromView: appDelegate.window!)
                }
            }
            
            print("URL: ",url)
            print("Request: ",InputParameter!)
            if let strResult = result {
                let jsonDictionary:NSDictionary = convertToDictionary(text: strResult)!
                print("Response: ",jsonDictionary)
            }

            if response.IsSuccess == true {
                
                ServiceCallBack(result, true)
            }
            else {
                
                switch response.Code {
                    
                case HttpCode.Error_500.rawValue?:
                    HttpParameter.CurrentHttpCode = HttpCode.Error_500
                    //Oops something went wrong
                    ServiceCallBack(nil, false)
                    _ = SCLAlertView().showError(AlertTitle.Error, subTitle:response.Message!, closeButtonTitle:ButtonTitle.btnOk)
                    break
                    
                case HttpCode.Error_503.rawValue?:
                    HttpParameter.CurrentHttpCode = HttpCode.Error_503
                    //Http Request Failur
                    ServiceCallBack(nil, false)
                    _ = SCLAlertView().showError(AlertTitle.Error, subTitle:response.Message!, closeButtonTitle:ButtonTitle.btnOk)
                    break
                    
                case HttpCode.Error_504.rawValue?:
                    HttpParameter.CurrentHttpCode = HttpCode.Error_504
                    //ServiceCallBack(nil, false)
                    
                    NoInternetVC.showNoInternetVC(completion: { (completionHandler) in
                        switch completionHandler {
                        case .Retry:
                            self.servicecall(url: url, HttpMethod: HttpMethod, InputParameter: InputParameter!, viewController:viewController, ServiceCallBack: ServiceCallBack)
                            break
                        default: break
                        }
                    })
                    break
                    
                case HttpCode.Error_410.rawValue?:
                    HttpParameter.CurrentHttpCode = HttpCode.Error_410
                    //Token Expierd
                    ServiceCallBack(nil, false)
                    _ = SCLAlertView().showError(AlertTitle.Error, subTitle:response.Message!, closeButtonTitle:ButtonTitle.btnOk)
                    break
                    
                case  HttpCode.Error_401.rawValue?:
                    HttpParameter.CurrentHttpCode = HttpCode.Error_401
                    //User Not Verify
                    ServiceCallBack(nil, false)
                    _ = SCLAlertView().showError(AlertTitle.Error, subTitle:response.Message!, closeButtonTitle:ButtonTitle.btnOk)
                    break
                    
                case  HttpCode.Error_400.rawValue?:
                    HttpParameter.CurrentHttpCode = HttpCode.Error_400
                    //Error Message
                    ServiceCallBack(nil, false)
                    break
                    
                default:
                    HttpParameter.CurrentHttpCode = HttpCode.Error_100
                    ServiceCallBack(nil, false)
                    _ = SCLAlertView().showError(AlertTitle.Error, subTitle:response.Message!, closeButtonTitle:ButtonTitle.btnOk)
                }
                
            }
        }
    }
    
    
    
    
    
    
    // Multiple Image Upload
    class func servicecallMultipleImageUpload(IsLoader:Bool? = true, imageDataFile: [Data] , url: String, HttpMethod: HTTPMethod, InputParameter: [String:String]? = nil , viewController:UIViewController? = nil, ServiceCallBack: @escaping (_ result: String?, _ IsSuccess: Bool?)-> Void) {
        
        if IsLoader == true {
            if viewController != nil {
                ProgressHUD.startLoading(onView: (viewController?.view)!)
            } else {
                ProgressHUD.startLoading(onView: appDelegate.window!)
            }
        }
       
        HttpRequest().serviceCallMultipleImageUploadHTTP(imageData: imageDataFile,url: url, HttpMethod: HttpMethod, parameter: InputParameter,viewController:viewController ) { (result, response) -> Void in
            
            if IsLoader == true {
                if viewController != nil {
                    ProgressHUD.stopLoading(fromView: (viewController?.view)!)
                } else {
                    ProgressHUD.stopLoading(fromView: appDelegate.window!)
                }
            }
            
            
            print("URL: ",url)
            print("Request: ",InputParameter!)
            if let strResult = result {
                let jsonDictionary:NSDictionary = convertToDictionary(text: strResult)!
                print("Response: ",jsonDictionary)
            }
            
            if response.IsSuccess == true {
                ServiceCallBack(result, true)
            } else {
            
                            switch response.Code {
            
                            case HttpCode.Error_500.rawValue?:
                                HttpParameter.CurrentHttpCode = HttpCode.Error_500
                                //Oops something went wrong
                                ServiceCallBack(nil, false)
                                _ = SCLAlertView().showError(AlertTitle.Error, subTitle:response.Message!, closeButtonTitle:ButtonTitle.btnOk)
                                break
            
                            case HttpCode.Error_503.rawValue?:
                                HttpParameter.CurrentHttpCode = HttpCode.Error_503
                                //Http Request Failur
                                ServiceCallBack(nil, false)
                                _ = SCLAlertView().showError(AlertTitle.Error, subTitle:response.Message!, closeButtonTitle:ButtonTitle.btnOk)
                                break
            
                            case HttpCode.Error_504.rawValue?:
                                HttpParameter.CurrentHttpCode = HttpCode.Error_504
                                //ServiceCallBack(nil, false)
            
                                NoInternetVC.showNoInternetVC(completion: { (completionHandler) in
                                    switch completionHandler {
                                    case .Retry:
                                        self.servicecall(url: url, HttpMethod: HttpMethod, InputParameter: InputParameter!, viewController:viewController, ServiceCallBack: ServiceCallBack)
                                        break
                                    default: break
                                    }
                                })
                                break
            
                            case HttpCode.Error_410.rawValue?:
                                HttpParameter.CurrentHttpCode = HttpCode.Error_410
                                //Token Expierd
                                ServiceCallBack(nil, false)
                                _ = SCLAlertView().showError(AlertTitle.Error, subTitle:response.Message!, closeButtonTitle:ButtonTitle.btnOk)
                                break
            
                            case  HttpCode.Error_401.rawValue?:
                                HttpParameter.CurrentHttpCode = HttpCode.Error_401
                                //User Not Verify
                                ServiceCallBack(nil, false)
                                _ = SCLAlertView().showError(AlertTitle.Error, subTitle:response.Message!, closeButtonTitle:ButtonTitle.btnOk)
                                break
            
                            case  HttpCode.Error_400.rawValue?:
                                HttpParameter.CurrentHttpCode = HttpCode.Error_400
                                //Error Message
                                ServiceCallBack(nil, false)
                                break
                                
                            default:
                                HttpParameter.CurrentHttpCode = HttpCode.Error_100
                                ServiceCallBack(nil, false)
                                _ = SCLAlertView().showError(AlertTitle.Error, subTitle:response.Message!, closeButtonTitle:ButtonTitle.btnOk)
                            }
                            
                        }
        
        }
    }
    
    class func servicecallMultipleImageUploadWithCompress(IsLoader:Bool? = true, imageFileList: [UIImage] , url: String, HttpMethod: HTTPMethod, InputParameter: [String:String]? = nil , viewController:UIViewController? = nil, ServiceCallBack: @escaping (_ result: String?, _ IsSuccess: Bool?)-> Void) {
        
        if IsLoader == true {
            if viewController != nil {
                ProgressHUD.startLoading(onView: (viewController?.view)!)
            } else {
                ProgressHUD.startLoading(onView: appDelegate.window!)
            }
        }
        
        var data : [Data] = []
        for i in (0..<(imageFileList.count)){
//            data.append((Common().getCompressImageData(image: imageFileList[i])) as Data)
            data.append(Common().getImageDatawithCompress(image: imageFileList[i], imgQty: 1.0, imgPer: 1.0, compressedQty: 0.75, compressedPer: 0.5, sizeLimit: 0.9) as Data)
        }
        HttpRequest().serviceCallMultipleImageUploadHTTP(imageData: data,url: url, HttpMethod: HttpMethod, parameter: InputParameter,viewController:viewController ) { (result, response) -> Void in
            
            if IsLoader == true {
                if viewController != nil {
                    ProgressHUD.stopLoading(fromView: (viewController?.view)!)
                } else {
                    ProgressHUD.stopLoading(fromView: appDelegate.window!)
                }
            }
            
            
            print("URL: ",url)
            print("Request: ",InputParameter!)
            if let strResult = result {
                let jsonDictionary:NSDictionary = convertToDictionary(text: strResult)!
                print("Response: ",jsonDictionary)
            }
            
            if response.IsSuccess == true {
                ServiceCallBack(result, true)
            } else {
                
                switch response.Code {
                    
                case HttpCode.Error_500.rawValue?:
                    HttpParameter.CurrentHttpCode = HttpCode.Error_500
                    //Oops something went wrong
                    ServiceCallBack(nil, false)
                    _ = SCLAlertView().showError(AlertTitle.Error, subTitle:response.Message!, closeButtonTitle:ButtonTitle.btnOk)
                    break
                    
                case HttpCode.Error_503.rawValue?:
                    HttpParameter.CurrentHttpCode = HttpCode.Error_503
                    //Http Request Failur
                    ServiceCallBack(nil, false)
                    _ = SCLAlertView().showError(AlertTitle.Error, subTitle:response.Message!, closeButtonTitle:ButtonTitle.btnOk)
                    break
                    
                case HttpCode.Error_504.rawValue?:
                    HttpParameter.CurrentHttpCode = HttpCode.Error_504
                    //ServiceCallBack(nil, false)
                    
                    NoInternetVC.showNoInternetVC(completion: { (completionHandler) in
                        switch completionHandler {
                        case .Retry:
                            self.servicecall(url: url, HttpMethod: HttpMethod, InputParameter: InputParameter!, viewController:viewController, ServiceCallBack: ServiceCallBack)
                            break
                        default: break
                        }
                    })
                    break
                    
                case HttpCode.Error_410.rawValue?:
                    HttpParameter.CurrentHttpCode = HttpCode.Error_410
                    //Token Expierd
                    ServiceCallBack(nil, false)
                    _ = SCLAlertView().showError(AlertTitle.Error, subTitle:response.Message!, closeButtonTitle:ButtonTitle.btnOk)
                    break
                    
                case  HttpCode.Error_401.rawValue?:
                    HttpParameter.CurrentHttpCode = HttpCode.Error_401
                    //User Not Verify
                    ServiceCallBack(nil, false)
                    _ = SCLAlertView().showError(AlertTitle.Error, subTitle:response.Message!, closeButtonTitle:ButtonTitle.btnOk)
                    break
                    
                case  HttpCode.Error_400.rawValue?:
                    HttpParameter.CurrentHttpCode = HttpCode.Error_400
                    //Error Message
                    ServiceCallBack(nil, false)
                    break
                    
                default:
                    HttpParameter.CurrentHttpCode = HttpCode.Error_100
                    ServiceCallBack(nil, false)
                    _ = SCLAlertView().showError(AlertTitle.Error, subTitle:response.Message!, closeButtonTitle:ButtonTitle.btnOk)
                }
                
            }
            
        }
    }
    
    class func servicecallMultipleImageUploadwithImageUrls(IsLoader:Bool? = true, imagePathList: [URL]? , url: String, HttpMethod: HTTPMethod, InputParameter: [String:String]? = nil , viewController:UIViewController? = nil, ServiceCallBack: @escaping (_ result: String?, _ IsSuccess: Bool?)-> Void) {
        
        if IsLoader == true {
            if viewController != nil {
                ProgressHUD.startLoading(onView: (viewController?.view)!)
            } else {
                ProgressHUD.startLoading(onView: appDelegate.window!)
            }
        }
        
        HttpRequest().serviceCallMultipleImageUploadWithPath(imagesPath: imagePathList, url: url, HttpMethod: HttpMethod, parameter: InputParameter,viewController:viewController ) { (result, response) -> Void in
            
            if IsLoader == true {
                if viewController != nil {
                    ProgressHUD.stopLoading(fromView: (viewController?.view)!)
                } else {
                    ProgressHUD.stopLoading(fromView: appDelegate.window!)
                }
            }
            
            
            print("URL: ",url)
            print("Request: ",InputParameter!)
            if let strResult = result {
                let jsonDictionary:NSDictionary = convertToDictionary(text: strResult)!
                print("Response: ",jsonDictionary)
            }
            
            if response.IsSuccess == true {
                ServiceCallBack(result, true)
            } else {
                
                switch response.Code {
                    
                case HttpCode.Error_500.rawValue?:
                    HttpParameter.CurrentHttpCode = HttpCode.Error_500
                    //Oops something went wrong
                    ServiceCallBack(nil, false)
                    _ = SCLAlertView().showError(AlertTitle.Error, subTitle:response.Message!, closeButtonTitle:ButtonTitle.btnOk)
                    break
                    
                case HttpCode.Error_503.rawValue?:
                    HttpParameter.CurrentHttpCode = HttpCode.Error_503
                    //Http Request Failur
                    ServiceCallBack(nil, false)
                    _ = SCLAlertView().showError(AlertTitle.Error, subTitle:response.Message!, closeButtonTitle:ButtonTitle.btnOk)
                    break
                    
                case HttpCode.Error_504.rawValue?:
                    HttpParameter.CurrentHttpCode = HttpCode.Error_504
                    //ServiceCallBack(nil, false)
                    
                    NoInternetVC.showNoInternetVC(completion: { (completionHandler) in
                        switch completionHandler {
                        case .Retry:
                            self.servicecall(url: url, HttpMethod: HttpMethod, InputParameter: InputParameter!, viewController:viewController, ServiceCallBack: ServiceCallBack)
                            break
                        default: break
                        }
                    })
                    break
                    
                case HttpCode.Error_410.rawValue?:
                    HttpParameter.CurrentHttpCode = HttpCode.Error_410
                    //Token Expierd
                    ServiceCallBack(nil, false)
                    _ = SCLAlertView().showError(AlertTitle.Error, subTitle:response.Message!, closeButtonTitle:ButtonTitle.btnOk)
                    break
                    
                case  HttpCode.Error_401.rawValue?:
                    HttpParameter.CurrentHttpCode = HttpCode.Error_401
                    //User Not Verify
                    ServiceCallBack(nil, false)
                    _ = SCLAlertView().showError(AlertTitle.Error, subTitle:response.Message!, closeButtonTitle:ButtonTitle.btnOk)
                    break
                    
                case  HttpCode.Error_400.rawValue?:
                    HttpParameter.CurrentHttpCode = HttpCode.Error_400
                    //Error Message
                    ServiceCallBack(nil, false)
                    break
                    
                default:
                    HttpParameter.CurrentHttpCode = HttpCode.Error_100
                    ServiceCallBack(nil, false)
                    _ = SCLAlertView().showError(AlertTitle.Error, subTitle:response.Message!, closeButtonTitle:ButtonTitle.btnOk)
                }
                
            }
            
        }
    }

    // Multiple Image Upload
    class func servicecallMultipleCategoryImageUpload(IsLoader:Bool? = true, imageDataFile: CategoryImageDataUpload<CategoryImagesNSDataList> , url: String, HttpMethod: HTTPMethod, InputParameter: [String:String]? = nil, imageKey:String?="", viewController:UIViewController? = nil, ServiceCallBack: @escaping (_ result: String?, _ IsSuccess: Bool?)-> Void) {
        
        if IsLoader == true {
            if viewController != nil {
                ProgressHUD.startLoading(onView: (viewController?.view)!)
            } else {
                ProgressHUD.startLoading(onView: appDelegate.window!)
            }
        }

        HttpRequest().serviceCallMultipleCategoryImageUploadHTTP(imageData: imageDataFile,url: url, HttpMethod: HttpMethod, parameter: InputParameter,viewController:viewController, imageKey: imageKey) { (result, response) -> Void in
            
            if IsLoader == true {
                if viewController != nil {
                    ProgressHUD.stopLoading(fromView: (viewController?.view)!)
                } else {
                    ProgressHUD.stopLoading(fromView: appDelegate.window!)
                }
            }
            
            
            print("URL: ",url)
            print("Request: ",InputParameter!)
            if let strResult = result {
                let jsonDictionary:NSDictionary = convertToDictionary(text: strResult)!
                print("Response: ",jsonDictionary)
            }
            
            if response.IsSuccess == true {
                ServiceCallBack(result, true)
            } else {
                
                switch response.Code {
                    
                case HttpCode.Error_500.rawValue?:
                    HttpParameter.CurrentHttpCode = HttpCode.Error_500
                    //Oops something went wrong
                    ServiceCallBack(nil, false)
                    _ = SCLAlertView().showError(AlertTitle.Error, subTitle:response.Message!, closeButtonTitle:ButtonTitle.btnOk)
                    break
                    
                case HttpCode.Error_503.rawValue?:
                    HttpParameter.CurrentHttpCode = HttpCode.Error_503
                    //Http Request Failur
                    ServiceCallBack(nil, false)
                    _ = SCLAlertView().showError(AlertTitle.Error, subTitle:response.Message!, closeButtonTitle:ButtonTitle.btnOk)
                    break
                    
                case HttpCode.Error_504.rawValue?:
                    HttpParameter.CurrentHttpCode = HttpCode.Error_504
                    //ServiceCallBack(nil, false)
                    
                    NoInternetVC.showNoInternetVC(completion: { (completionHandler) in
                        switch completionHandler {
                        case .Retry:
                            self.servicecall(url: url, HttpMethod: HttpMethod, InputParameter: InputParameter!, viewController:viewController, ServiceCallBack: ServiceCallBack)
                            break
                        default: break
                        }
                    })
                    break
                    
                case HttpCode.Error_410.rawValue?:
                    HttpParameter.CurrentHttpCode = HttpCode.Error_410
                    //Token Expierd
                    ServiceCallBack(nil, false)
                    _ = SCLAlertView().showError(AlertTitle.Error, subTitle:response.Message!, closeButtonTitle:ButtonTitle.btnOk)
                    break
                    
                case  HttpCode.Error_401.rawValue?:
                    HttpParameter.CurrentHttpCode = HttpCode.Error_401
                    //User Not Verify
                    ServiceCallBack(nil, false)
                    _ = SCLAlertView().showError(AlertTitle.Error, subTitle:response.Message!, closeButtonTitle:ButtonTitle.btnOk)
                    break
                    
                case  HttpCode.Error_400.rawValue?:
                    HttpParameter.CurrentHttpCode = HttpCode.Error_400
                    //Error Message
                    ServiceCallBack(nil, false)
                    break
                    
                default:
                    HttpParameter.CurrentHttpCode = HttpCode.Error_100
                    ServiceCallBack(nil, false)
                    _ = SCLAlertView().showError(AlertTitle.Error, subTitle:response.Message!, closeButtonTitle:ButtonTitle.btnOk)
                }
                
            }
            
        }
    }
    
    class func convertToDictionary(text: String) -> NSDictionary? {
        if let data = text.data(using: .utf8) {
            do {
                return try JSONSerialization.jsonObject(with: data, options: []) as? NSDictionary
            } catch {
                print(error.localizedDescription)
            }
        }
        return nil
    }
    
    
    // Multiple Image Upload
    class func servicecallMultipleImageUploadArr(imgURLs : [URL], IsLoader:Bool? = true , url: String, HttpMethod: HTTPMethod, InputParameter: [String:String]? = nil , viewController:UIViewController? = nil, ServiceCallBack: @escaping (_ result: String?, _ IsSuccess: Bool?)-> Void) {
        
        if IsLoader == true {
            if viewController != nil {
                ProgressHUD.startLoading(onView: (viewController?.view)!)
            } else {
                ProgressHUD.startLoading(onView: appDelegate.window!)
            }
        }
        
        HttpRequest().serviceCallMultipleImageUploadHTTPArr(imgURLs: imgURLs,url: url, HttpMethod: HttpMethod, parameter: InputParameter,viewController:viewController ) { (result, response) -> Void in
            
            if IsLoader == true {
                if viewController != nil {
                    ProgressHUD.stopLoading(fromView: (viewController?.view)!)
                } else {
                    ProgressHUD.stopLoading(fromView: appDelegate.window!)
                }
            }
            
            
            print("URL: ",url)
            print("Request: ",InputParameter!)
            if let strResult = result {
                let jsonDictionary:NSDictionary = convertToDictionary(text: strResult)!
                print("Response: ",jsonDictionary)
            }
            
            if response.IsSuccess == true {
                ServiceCallBack(result, true)
            } else {
                
                switch response.Code {
                    
                case HttpCode.Error_500.rawValue?:
                    HttpParameter.CurrentHttpCode = HttpCode.Error_500
                    //Oops something went wrong
                    ServiceCallBack(nil, false)
                    _ = SCLAlertView().showError(AlertTitle.Error, subTitle:response.Message!, closeButtonTitle:ButtonTitle.btnOk)
                    break
                    
                case HttpCode.Error_503.rawValue?:
                    HttpParameter.CurrentHttpCode = HttpCode.Error_503
                    //Http Request Failur
                    ServiceCallBack(nil, false)
                    _ = SCLAlertView().showError(AlertTitle.Error, subTitle:response.Message!, closeButtonTitle:ButtonTitle.btnOk)
                    break
                    
                case HttpCode.Error_504.rawValue?:
                    HttpParameter.CurrentHttpCode = HttpCode.Error_504
                    //ServiceCallBack(nil, false)
                    
                    NoInternetVC.showNoInternetVC(completion: { (completionHandler) in
                        switch completionHandler {
                        case .Retry:
                            self.servicecall(url: url, HttpMethod: HttpMethod, InputParameter: InputParameter!, viewController:viewController, ServiceCallBack: ServiceCallBack)
                            break
                        default: break
                        }
                    })
                    break
                    
                case HttpCode.Error_410.rawValue?:
                    HttpParameter.CurrentHttpCode = HttpCode.Error_410
                    //Token Expierd
                    ServiceCallBack(nil, false)
                    _ = SCLAlertView().showError(AlertTitle.Error, subTitle:response.Message!, closeButtonTitle:ButtonTitle.btnOk)
                    break
                    
                case  HttpCode.Error_401.rawValue?:
                    HttpParameter.CurrentHttpCode = HttpCode.Error_401
                    //User Not Verify
                    ServiceCallBack(nil, false)
                    _ = SCLAlertView().showError(AlertTitle.Error, subTitle:response.Message!, closeButtonTitle:ButtonTitle.btnOk)
                    break
                    
                case  HttpCode.Error_400.rawValue?:
                    HttpParameter.CurrentHttpCode = HttpCode.Error_400
                    //Error Message
                    ServiceCallBack(nil, false)
                    break
                    
                default:
                    HttpParameter.CurrentHttpCode = HttpCode.Error_100
                    ServiceCallBack(nil, false)
                    _ = SCLAlertView().showError(AlertTitle.Error, subTitle:response.Message!, closeButtonTitle:ButtonTitle.btnOk)
                }
                
            }
            
        }
    }
    
    
}

