//
//  WelcomeVC.swift
//  HealthSample
//
//  Created by KairaNewMac on 16/11/17.
//  Copyright © 2017 Kaira NewMac. All rights reserved.
//

import UIKit

class WelcomeVC: UIViewController {

    @IBOutlet var IBbarbtnBack                      : UIBarButtonItem!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.helthActivity()
        self.setView()
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

//MARK: - IBAction Methods
extension WelcomeVC {
    
    //btnBack Click
    @IBAction func barbtnBackClick(sender: AnyObject) {
        _ =  self.navigationController?.popViewController(animated: true)
    }
    
}

//MARK: - Other Methods
extension WelcomeVC {
    
    func setView() {
        self.navigationController!.navigationBar.titleTextAttributes    = [NSForegroundColorAttributeName: UIColor.darkGray]
        self.navigationItem.leftBarButtonItem                           = IBbarbtnBack
        self.title = "Success"
    }
}

//MARK: - Service Call
extension WelcomeVC {
    
    func helthActivity() {
        let objHealthActivityPost : HealthActivityPost        = HealthActivityPost()
        
        objHealthActivityPost.UserID            = Preference.GetInteger(key: UserDefaultsKey.UserId)
        objHealthActivityPost.Platform          = "IOS"
        objHealthActivityPost.PlatFormUserID    = ""
        objHealthActivityPost.ActivityDetails   = "Test Activity"
        
        let securitydataprovider: SecurityDataProvider = SecurityDataProvider()
        securitydataprovider.HealthActivity(healthActivity: objHealthActivityPost,IsLoader: true, viewController: self) { (response, IsSuccess) -> Void in
            //code
            if IsSuccess! {
                Preference.PutInteger(key: UserDefaultsKey.UserHealthActivityID, value: (response?.Data?.UserHealthActivityID)!)
            } else { }
        }
    }
    
}
