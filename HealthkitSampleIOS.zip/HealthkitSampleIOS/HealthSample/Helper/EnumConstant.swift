//
//  EnumConstant.swift
//  iOSProject
//
//  Created by KairaNewMac on 14/12/16.
//  Copyright © 2016 Kaira NewMac. All rights reserved.
//

import Foundation
import UIKit


enum HttpCode: String {
    case Error_100 = "100" //None
    case Error_500 = "500" //Oops something went wrong
    case Error_503 = "503" //Http Request Failur
    case Error_504 = "504" //No InternetConnection
    case Error_410 = "410" //Token Expierd
    case Error_400 = "400" //Error Message
    case Error_401 = "401" //User Not Verify
    case Error_200 = "200" //Succsessfull
    case Error_203 = "203" //Succsessfull
}
