//
//  Common.swift
//  MoreCustomersApp
//
//  Created by Kaira NewMac on 1/20/17.
//  Copyright © 2017 Kaira NewMac. All rights reserved.
//

import Foundation
import AVFoundation
//import FBSDKShareKit
import SkyFloatingLabelTextField
import SafariServices
import Contacts
//import ObjectMapper

class Common {
    
    func Validate(value:String,Regex:String) -> Bool {
        let test = NSPredicate(format: "SELF MATCHES %@", Regex)
        let result =  test.evaluate(with: value)
        return result
    }
    
    func applySkyscannerTheme(textField: SkyFloatingLabelTextField) {
        
        textField.tintColor = AppColor.Light_Grey //color
        
        textField.textColor =  UIColor.darkGray //overcastBlueColor
        textField.lineColor = AppColor.Light_Grey
        
        textField.selectedTitleColor    = AppColor.AppTheme_Primary //AppColor.Dark_Gray
        textField.selectedLineColor     = AppColor.AppTheme_Primary //AppColor.Dark_Gray
        
        textField.lineHeight = 1.0
        textField.selectedLineHeight = 0.7
        
        // Set custom fonts for the title, placeholder and textfield labels
        textField.titleLabel.font =  AppFont.HelveticaNeue_12
        textField.placeholderFont = AppFont.HelveticaNeue_14
        textField.font = AppFont.HelveticaNeue_14
    }

    func getImageDatawithCompress(image: UIImage, imgQty:CGFloat, imgPer:CGFloat, compressedQty:CGFloat, compressedPer:CGFloat, sizeLimit:Float) -> NSData {
        
        var imgNew = image.resizeWithPercentage(percentage: imgPer)
        let imgData = UIImageJPEGRepresentation(imgNew!, imgQty)! as NSData
        let fileSize = Float(imgData.length/1024/1024)
        
        if fileSize > sizeLimit {
            imgNew = self.getimageFromData(imgData: imgData)
            //            self.getImageDatawithCompress(image: imgNew!, imgQty: compressedQty, imgPer: compressedPer)
            return getImageDatawithCompress(image: imgNew!, imgQty: compressedQty, imgPer: compressedPer, compressedQty: compressedQty, compressedPer: compressedPer, sizeLimit: sizeLimit)
        }
        return imgData
    }
    
    func getimageFromData(imgData: NSData) -> UIImage {
        
        //        return UIImage(data: imgData as Data, scale: scaleValue)!
        return UIImage(data: imgData as Data)!
    }
}




