//
//  UserDefaults.swift
//  iOSProject
//
//  Created by Kaira NewMac on 12/8/16.
//  Copyright © 2016 Kaira NewMac. All rights reserved.
//

import Foundation

struct UserDefaultsKey {
    
    static let IsSupportNoStore                    = "IsSupportNoStore"
    
    static let UserId                           = "UserId"
    static let UserHealthActivityID             = "UserHealthActivityID"
    
    static let LeadId                           = "LeadId"
    static let SiteID                           = "SiteID"
    static let FirmID                           = "FirmID"
    static let Steps                            = "Steps"
    static let LookUp                           = "LookUp"
    static let SocialAlert                      = "SocialAlert"
    
    static let FBPromoteURL                     = "FBPromoteURL"

    
    static let SiteVisitorID                    = "SiteVisitorID"
    static let UserName                         = "UserName"
    static let FirstName                        = "FirstName"
    static let LastName                         = "LastName"
    static let Email                            = "Email"
    static let Mobile                           = "Mobile"
    
    static let FacebookEmail                    = "FacebookEmail"
    static let FacebookName                     = "FacebookName"
    static let FacebookID                       = "FacebookID"
    static let GooglePlusID                     = "GooglePlusID"
    static let isUserPaid                       = "isUserPaid"
    static let DeviceUDID                       = "DeviceUDID" //For System UUID
    static let Platform                         = "Platform"
    static let ProfileUrl                       = "ProfileUrl"
    static let City                             = "City"
    static let Password                         = "Password"
    static let DomainName                       = "DomainName"
    static let FullImagePath                    = "FullImagePath"
    
    
    static let DeviceToken                      = "DeviceToken" // For Notification
    static let Token                            = "Token"
    static let CurrentScreen                    = "CurrentScreen"
    
    static let SectionBanner1                   = "SectionBanner1"
    static let SectionBanner2                   = "SectionBanner2"
    static let Gallery                          = "Gallery"
    
    static let FirmName                         = "FirmName"
    static let LogoImage                        = "LogoImage"
    static let Slider1                          = "Slider1"
    static let Slider2                          = "Slider2"
    static let Slider3                          = "Slider3"
    static let Slider4                          = "Slider4"
    static let AboutusBanner                    = "AboutusBanner"
    static let AboutusCompanylogo               = "AboutusCompanylogo"
    static let VisitorStoreBanner               = "VisitorStoreBanner"
    static let VisitorStoreLogo                 = "VisitorStoreLogo"
    static let ContactUsBanner                  = "ContactUsBanner"
    static let WishListBanner                   = "WishListBanner"
    static let TermsCondition                   = "TermsCondition"
    static let EnquiryBanner                    = "EnquiryBanner"
    
    static let CurrencySymbol                   = "CurrencySymbol"
    static let HomeLabel1                       = "HomeLabel1"
    static let HomeLabel2                       = "HomeLabel2"
    static let HomeLabel3                       = "HomeLabel3"
    static let HomeLabel4                       = "HomeLabel4"
    
    static let FirmFullDescription              = "FirmFullDescription"
    static let FirmShortDescription             = "FirmShortDescription"
    
    //For Set Screen
    static let IsToturial                       = "IsToturial"
    static let IsCreateBusiness                 = "IsCreateBusiness"
    static let IsCompleteSetup                  = "IsCompleteSetup"
    static let IsLogin                          = "IsLogin"
    static let IsDashboard                      = "IsDashboard"
    static let IsVerify                         = "IsVerify"
    
    static let IsLogo                           = "IsLogo"
    static let IsPrimaryColor                   = "IsPrimaryColor"
    static let IsCoverPhoto                     = "IsCoverPhoto"
    static let IsCategory                       = "IsCategory"
    static let IsBusinessDescriptionAdded       = "IsBusinessDescriptionAdded"
    
    static let LastDayPostViews                 = "LastDayPostViews"
    static let LastDayProductViews              = "LastDayProductViews"
    static let NewInquiriesCount                = "NewInquiriesCount"
    static let NewOrdersCount                   = "NewOrdersCount"
    static let NewSubscribersCount              = "NewSubscribersCount"
    static let TodayPostViews                   = "TodayPostViews"
    static let TodayProductViews                = "TodayProductViews"
    
    static let txtViewMore                      = "ViewMore"
    
    
    
}

class Preference {
    
    static let defaults = UserDefaults.standard
    
    static func PutInteger(key : String , value : Int){
        defaults.set(value, forKey: key)
    }
    
    static func GetInteger(key : String) -> Int {
        if(isKeyNull(key: key) == true)
        {
            return 0
        }
        else
        {
            return defaults.integer(forKey: key)
        }
       
    }
    
    static func PutString(key : String , value : String? = ""){
        defaults.set(value, forKey: key)
    }
    static func PutObject(key : String , value : String? = ""){
        defaults.set(value, forKey: key)
    }
    
    static func GetString(key : String) -> String? {
        if(isKeyNull(key: key) == true)
        {
            return ""
        }
        else
        {
            return defaults.string(forKey: key)!
        }
    }
    
    static func PutImage(key : String , value : String){
        defaults.set(value, forKey: key)}
    
    static func GetImage(key : String) -> String? {
        if(isKeyNull(key: key) == true)
        {
            return ""
        }
        else
        {
            return defaults.string(forKey: key)!
        }
    }
    
    static func PutBool(key : String , value : Bool) {
        defaults.set(value, forKey: key)
    }
    
    static func GetBool(key : String ) -> Bool {
        if(isKeyNull(key: key) == true)
        {
            return false
        }
        else
        {
           return defaults.bool(forKey: key)
        }
    }
    
    static func isKeyNull (key: String) -> Bool
    {
        if(defaults.object(forKey: key) != nil)
        {
            return false
        }
        return true
    }
    
    static func prefrenceClearAll(){
        let appDomain = Bundle.main.bundleIdentifier!
        UserDefaults.standard.removePersistentDomain(forName: appDomain)
    }
    
    static func prefrenceClear() {
        
        Preference.PutString (key: UserDefaultsKey.Token, value: "")
        Preference.PutString (key: UserDefaultsKey.SiteVisitorID, value: "")
        Preference.PutString (key: UserDefaultsKey.FirstName, value: "")
        Preference.PutString (key: UserDefaultsKey.LastName, value: "")
        Preference.PutString (key: UserDefaultsKey.UserName, value: "")
        Preference.PutString (key: UserDefaultsKey.Email, value: "")
        Preference.PutString (key: UserDefaultsKey.Mobile, value: "")
        Preference.PutString (key: UserDefaultsKey.ProfileUrl, value: "")
        Preference.PutInteger (key: UserDefaultsKey.SiteID, value: 0)
        Preference.PutInteger (key: UserDefaultsKey.UserId, value: 0)
        Preference.PutInteger (key: UserDefaultsKey.FirmID, value: 0)
        Preference.PutInteger (key: UserDefaultsKey.LeadId, value: 0)
        Preference.PutInteger (key: UserDefaultsKey.Steps, value: 0)
        Preference.PutString (key: UserDefaultsKey.DomainName, value: "")
        Preference.PutString (key: UserDefaultsKey.txtViewMore, value: "View More")
    }
}
