//
//  serviceRequest.swift
//  iOSProject
//
//  Created by Kaira NewMac on 12/8/16.
//  Copyright © 2016 Kaira NewMac. All rights reserved.
//

import UIKit
import ObjectMapper

class ServiceRequest<T: Mappable>: Mappable {
    
    var Key: String?
    var Token: String?
    var Slug: String?
    var Data : T?
    
    init() {
        
        if (UserDefaults.standard.object(forKey: UserDefaultsKey.Token) != nil && ((Preference.GetString(key : UserDefaultsKey.Token)!.isEmpty) == false)) {
            Token = Preference.GetString(key : UserDefaultsKey.Token)!
        }else{
            Token=""
        }
        Key = AppConstant.APIKey
        Slug = AppConstant.AppSiteSlug
    }
    
    required init?(map: Map) {
        
    }
    
    func mapping(map: Map) {
        
        Key         <- map["Key"]
        Token      <- map["Token"]
        Slug      <- map["Slug"]
        Data       <- map["Data"]
        
    }
}

class ServiceRequestArray<T: Mappable>: Mappable {
    
    var Key: String?
    var Token: String?
    var Slug: String?
    
    
    var Data : [T]?
    
    init() {
        
        if (UserDefaults.standard.object(forKey: UserDefaultsKey.Token) != nil && ((Preference.GetString(key : UserDefaultsKey.Token)!.isEmpty) == false)) {
            Token = Preference.GetString(key : UserDefaultsKey.Token)!
            
        }else{
            Token=""
        }
        Key=AppConstant.APIKey;
        Slug = AppConstant.AppSiteSlug
    }
    
    required init?(map: Map) {
        
    }
    
    func mapping(map: Map) {
        
        Key         <- map["Key"]
        Token      <- map["Token"]
        Slug      <- map["Slug"]
        Data       <- map["Data"]
    }
}

class ServiceRequestData<T: Mappable>: Mappable {
    
    var Data : T?
    
    init() {
    }
    
    required init?(map: Map) {
    }
    
    func mapping(map: Map) {
        Data       <- map["Data"]
    }
}

