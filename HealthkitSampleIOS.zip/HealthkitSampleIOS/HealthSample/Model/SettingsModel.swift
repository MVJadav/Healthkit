//
//  SettingsModel.swift
//  MoreCustomersApp
//
//  Created by Kaira NewMac on 4/18/17.
//  Copyright © 2017 Kaira NewMac. All rights reserved.
//

import Foundation
import ObjectMapper

//MARK: - Category Image Uploade Model
class CategoryImageUpload<T: Mappable>: Mappable {
    
    lazy var CategoryImagesList          : [T]? = []
    
    required init(){
    }
    required init?(map: Map) {
    }
    func mapping(map: Map) {
        CategoryImagesList           <- map["CategoryImagesList"]
    }
}

class CategoryImagesList: Mappable {
    
    lazy var Image              : UIImage?  = nil
    lazy var Key                : String?   = ""
    
    required init() {
    }
    
    required init?(map: Map) {
    }
    
    func mapping(map: Map) {
        
        Image               <- map["Image"]
        Key                 <- map["Key"]
    }
}


class CategoryImageDataUpload<T: Mappable>: Mappable {
    
    lazy var CategoryImagesNSDataList          : [T]? = []
    
    required init(){
    }
    required init?(map: Map) {
    }
    func mapping(map: Map) {
        CategoryImagesNSDataList           <- map["CategoryImagesNSDataList"]
    }
}

class CategoryImagesNSDataList: Mappable {
    
    lazy var Data           : NSData?  = nil
    lazy var Key            : String?   = ""
    
    required init() {
    }
    
    required init?(map: Map) {
    }
    
    func mapping(map: Map) {
        
        Data            <- map["Data"]
        Key             <- map["Key"]
    }
}

