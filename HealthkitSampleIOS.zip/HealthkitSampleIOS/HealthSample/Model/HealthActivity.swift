//
//  HealthActivity.swift
//  HealthSample
//
//  Created by KairaNewMac on 16/11/17.
//  Copyright © 2017 Kaira NewMac. All rights reserved.
//

import UIKit
import ObjectMapper


class HealthActivityPost: Mappable {
    
    lazy var UserID             : CLong? = 0
    lazy var Platform           : String? = ""
    lazy var PlatFormUserID     : String? = ""
    lazy var ActivityDetails    : String? = ""
    
    required init(){
    }
    required init?(map: Map) {
    }
    
    func mapping(map: Map) {
        
        UserID                  <- map["UserID"]
        Platform                <- map["Platform"]
        PlatFormUserID          <- map["PlatFormUserID"]
        ActivityDetails     <- map["ActivityDetails"]
        
    }
}

class HealthActivity: Mappable {
    
    lazy var UserHealthActivityID             : CLong? = 0
    
    required init(){
    }
    required init?(map: Map) {
    }
    
    func mapping(map: Map) {
        UserHealthActivityID         <- map["UserHealthActivityID"]
    }
}

