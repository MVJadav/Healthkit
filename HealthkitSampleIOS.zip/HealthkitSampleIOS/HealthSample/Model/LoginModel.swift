//
//  LoginModel.swift
//  HealthSample
//
//  Created by KairaNewMac on 16/11/17.
//  Copyright © 2017 Kaira NewMac. All rights reserved.
//

import UIKit
import ObjectMapper


class LoginPostModel: Mappable {

    lazy var EmailID        : String? = ""
    lazy var FirstName      : String? = ""
    lazy var LastName       : String? = ""
    lazy var MobileNumber   : String? = ""
    lazy var GoogleFitUser  : Bool? = false
    lazy var FitbitUser     : Bool? = false
    lazy var HealthKitUser  : Bool? = false

    required init(){
    }
    required init?(map: Map) {
    }
    
    func mapping(map: Map) {
        
        EmailID         <- map["EmailID"]
        FirstName       <- map["FirstName"]
        LastName        <- map["LastName"]
        MobileNumber    <- map["MobileNumber"]
        GoogleFitUser   <- map["GoogleFitUser"]
        FitbitUser      <- map["FitbitUser"]
        HealthKitUser   <- map["HealthKitUser"]
        
    }
}


//MARK: - Login GET Model
 
class LoginGetModel: Mappable{
    
    lazy var UserID : CLong? = 0
    
    required init(){
        
    }
    required init?(map : Map) {
        
    }
    func mapping(map: Map) {
        UserID              <- map["UserID"]
    }
}
