//
//  UserProfile.swift
//  HealthSample
//
//  Created by Kaira NewMac on 14/11/17.
//  Copyright © 2017 Kaira NewMac. All rights reserved.
//

import UIKit
import SkyFloatingLabelTextField

class UserProfile: UIViewController {

    @IBOutlet weak var IBbtnLogin           : UIButton!
    @IBOutlet weak var IBtxtFname           : SkyFloatingLabelTextField!
    @IBOutlet weak var IBtxtLname           : SkyFloatingLabelTextField!
    @IBOutlet weak var IBtxtMobile          : SkyFloatingLabelTextField!
    @IBOutlet weak var IBtxtEmail           : SkyFloatingLabelTextField!
    @IBOutlet weak var IBcheckHealthKitUser : UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setView()
        self.setSkyFloatingTextField()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    @IBAction func clickLogin(_ sender: Any) {
        self.dismissKeyboard()
        if ValidationAll() == true {
            
            //Service Call
            self.loginServiceCall()
        }
    }
    
    @IBAction func clickHechKitUser(_ sender: Any) {
        
        if IBcheckHealthKitUser.isSelected == true {
           IBcheckHealthKitUser.isSelected = false
        } else {
           IBcheckHealthKitUser.isSelected = true
        }
    }
    
}

//MARK: - Other Methods
extension UserProfile {
    
    func setView() {
        
        self.IBbtnLogin.backgroundColor = AppColor.AppTheme_Primary
        self.IBbtnLogin.setTitleColor(UIColor.white, for: .normal)
        
//        self.navigationController!.navigationBar.barTintColor           = AppColor.AppTheme_Primary
        self.navigationController!.navigationBar.titleTextAttributes    = [NSForegroundColorAttributeName: UIColor.darkGray]
        self.title                                                      = "Login"
        
    }
    
    func setSkyFloatingTextField(){
     
        Common().applySkyscannerTheme(textField: self.IBtxtFname)
        Common().applySkyscannerTheme(textField: self.IBtxtLname)
        Common().applySkyscannerTheme(textField: self.IBtxtMobile)
        Common().applySkyscannerTheme(textField: self.IBtxtEmail)
    }
    
    func dismissKeyboard() {
        
        IBtxtFname.resignFirstResponder()
        IBtxtLname.resignFirstResponder()
        IBtxtMobile.resignFirstResponder()
        IBtxtEmail.resignFirstResponder()
    }
    
    func redirection() {
        let objWelcomeVC = WelcomeVC(nibName: "WelcomeVC", bundle: nil)
        self.navigationController?.pushViewController(objWelcomeVC, animated: true)
    }
}

//MARK: - Validation
extension UserProfile {
    
    func ValidationAll() -> Bool{
        var falg:Bool = true
        if(self.Validation(textField: self.IBtxtFname) == false){
            falg = false
        }
        if(self.Validation(textField: self.IBtxtLname) == false){
            falg = false
        }
        if(self.Validation(textField: self.IBtxtMobile) == false){
            falg = false
        }
        if(self.Validation(textField: self.IBtxtEmail) == false){
            falg = false
        }
        return falg
    }
    
    
    func Validation(textField: UITextField) -> Bool {
        var flag:Bool = true
        
        if textField == IBtxtFname {
            if IBtxtFname.text?.isEmptyField == true {
                self.IBtxtFname.lineColor = AppColor.Red
                flag = false
            } else {
                self.IBtxtFname.lineColor = AppColor.Light_Grey
            }
        }
        if textField == IBtxtLname {
            if IBtxtLname.text?.isEmptyField == true {
                self.IBtxtLname.lineColor = AppColor.Red
                flag = false
            } else {
                self.IBtxtLname.lineColor = AppColor.Light_Grey
            }
        }
        
        if textField == IBtxtMobile {
            if IBtxtMobile.text?.isEmptyField == true {
                self.IBtxtMobile.lineColor = AppColor.Red
                flag = false
            } else {
                self.IBtxtMobile.lineColor = AppColor.Light_Grey
            }
        }
        
        if IBtxtEmail.text?.isEmptyField == true {
            flag = false
            self.IBtxtEmail.errorMessage = ""
            self.IBtxtEmail.lineColor = AppColor.Red
        }
        else if Common().Validate(value: IBtxtEmail.text!, Regex: RegularExpression.REGEX_EMAIL) != true {
            flag = false
            self.IBtxtEmail.errorMessage = ValidationMessage.emailError
        }
        else{
            self.IBtxtEmail.errorMessage = ""
            self.IBtxtEmail.lineColor = AppColor.Light_Grey
        }
        
        return flag
    }
}


//MARK: - UITextField Delegate methods
extension UserProfile: UITextFieldDelegate {

    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        if(textField==self.IBtxtFname){
            let maxLength = 20
            let currentString: NSString = textField.text! as NSString
            let newString: NSString = currentString.replacingCharacters(in: range, with: string) as NSString
            return newString.length <= maxLength
        }else if(textField==self.IBtxtLname){
            let maxLength = 20
            let currentString: NSString = textField.text! as NSString
            let newString: NSString = currentString.replacingCharacters(in: range, with: string) as NSString
            return newString.length <= maxLength
        }else if(textField==self.IBtxtMobile){
            let maxLength = 10
            let currentString: NSString = textField.text! as NSString
            let newString: NSString = currentString.replacingCharacters(in: range, with: string) as NSString
            return newString.length <= maxLength
        }else if(textField==self.IBtxtEmail){
            let maxLength = 50
            let currentString: NSString = textField.text! as NSString
            let newString: NSString = currentString.replacingCharacters(in: range, with: string) as NSString
            return newString.length <= maxLength
        }
        return true
    }
    
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        //        else if textField == IBtxtDomain {
        //            return false
        //        }
        return true
    }
    
    func textFieldShouldEndEditing(_ textField: UITextField) -> Bool {
        _ = self.Validation(textField: textField)
        return true
    }
    
}

//MARK: - Service Call
extension UserProfile {
    
    func loginServiceCall() {
    
        let objloginPostModel:LoginPostModel        = LoginPostModel()
        objloginPostModel.FirstName = self.IBtxtFname.text!
        objloginPostModel.LastName = self.IBtxtLname.text!
        objloginPostModel.MobileNumber = self.IBtxtMobile.text!
        objloginPostModel.EmailID = self.IBtxtEmail.text!
        objloginPostModel.HealthKitUser = self.IBcheckHealthKitUser.isSelected
        
        let securitydataprovider: SecurityDataProvider = SecurityDataProvider()
        securitydataprovider.Login(loginModel: objloginPostModel,IsLoader: true, viewController: self) { (response, IsSuccess) -> Void in
            //code
            if IsSuccess! {
                Preference.PutInteger(key: UserDefaultsKey.UserId, value: (response?.Data?.UserID)!)
                self.redirection()
            }
            else {
            }
        }
        
        
    }
    
}







