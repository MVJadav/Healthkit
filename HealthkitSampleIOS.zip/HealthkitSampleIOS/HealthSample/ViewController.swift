//
//  ViewController.swift
//  HealthSample
//
//  Created by Kaira NewMac on 13/11/17.
//  Copyright © 2017 Kaira NewMac. All rights reserved.
//

import UIKit
import HealthKit
import CoreMotion

class ViewController: UIViewController {

    @IBOutlet weak var IBlblStepCount       : UILabel!
    @IBOutlet weak var IBavgSteps           : UILabel!
    @IBOutlet weak var IBlblSpeed           : UILabel!
    @IBOutlet weak var IBlblDuration        : UILabel!
    @IBOutlet weak var IBlblResting         : UILabel!
    @IBOutlet weak var IBlblActive          : UILabel!
    @IBOutlet weak var IBlblConsumed        : UILabel!
    @IBOutlet weak var IBlblNet             : UILabel!
    @IBOutlet weak var IBlblDistancve       : UILabel!
    @IBOutlet weak var IBlblMotion          : UILabel!
    @IBOutlet weak var IBbtn                : UIButton!
    var healthStore: HKHealthStore?
    
    let activityManager = CMMotionActivityManager()
    let pedoMeter = CMPedometer()
    var days:[String] = []
    var stepsTaken:[Int] = []
    
    fileprivate var stepsCount: Double = 0.0 {
        didSet {
            didSetStepCount(oldValue)
        }
    }
    fileprivate var activeEnergyBurned: Double = 0.0 {
        didSet {
            didSetActiveEnergyBurned(oldValue)
        }
    }
    fileprivate var restingEnergyBurned: Double = 0.0 {
        didSet {
            didSetRestingEnergyBurned(oldValue)
        }
    }
    fileprivate var energyConsumed: Double = 0.0 {
        didSet {
            didSetEnergyConsumed(oldValue)
        }
    }
    fileprivate var netEnergy: Double = 0.0 {
        didSet {
            didSetNetEnergy(oldValue)
        }
    }
    fileprivate var distance: Double = 0.0 {
        didSet {
            didSetDistance(oldValue)
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        self.setView()
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(true)
        self.checkHealthKitAvaibility()
//        self.checkAvaibility()
        
    }
    
    
    
    func setView() {
        
        var cal = NSCalendar.current
//        var comps = cal.components(NSCalendar.Unit.year | .month | .day | .ho | .MinuteCalendarUnit | .SecondCalendarUnit, fromDate: NSDate())
        var comps = cal.dateComponents([.year, .month, .day, .hour, .minute, .second], from: Date())
        comps.hour = 0
        comps.minute = 0
        comps.second = 0
        let timeZone = NSTimeZone.system
        cal.timeZone = timeZone
        let midnightOfToday = cal.date(from: comps)
//        let midnightOfToday = cal.dateFromComponents(comps)!
        
        if(CMMotionActivityManager.isActivityAvailable()){
            self.activityManager.startActivityUpdates(to: OperationQueue.main, withHandler: { (data: CMMotionActivity!) -> Void in
                DispatchQueue.main.async(execute: { () -> Void in
                    if(data.stationary == true){
                        self.IBlblMotion.text = "Stationary"
//                        self.stateImageView.image = UIImage(named: "Sitting")
                        print("Stationary")
                    } else if (data.walking == true){
                        self.IBlblMotion.text = "Walking"
//                        self.stateImageView.image = UIImage(named: "Walking")
                        print("Walking")
                    } else if (data.running == true){
                        self.IBlblMotion.text = "Running"
//                        self.stateImageView.image = UIImage(named: "Running")
                        print("Running")
                    } else if (data.automotive == true){
                        self.IBlblMotion.text = "Automotive"
                        print("Automotive")
                    }
                })
                
            })
        }
        if(CMPedometer.isStepCountingAvailable()){
            
            let fromDate = NSDate(timeIntervalSinceNow: -86400 * 7)
            self.pedoMeter.queryPedometerData(from: fromDate as Date, to: NSDate() as Date) { (data : CMPedometerData!, error) -> Void in
                print(data)
                DispatchQueue.main.async(execute: { () -> Void in
                    if(error == nil){
                        self.IBavgSteps.text = "From Motion : \(data.numberOfSteps)"
                        self.IBlblDistancve.text = "From Motion : \(data.distance ?? 0)"
                    }
                })
            }
            
            self.pedoMeter.startUpdates(from: midnightOfToday!) { (data: CMPedometerData!, error) -> Void in
                DispatchQueue.main.async(execute: { () -> Void in
                    if(error == nil){
                        self.IBavgSteps.text = "Motion Step : \(data.numberOfSteps)"
                        self.IBlblDistancve.text = "Motion Distance : \(data.distance ?? 0)"
                    }
                })
            }
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //MARK: - NSEnergyFormatter
    fileprivate lazy var energyFormatter: EnergyFormatter = {
        let formatter = EnergyFormatter()
        formatter.unitStyle = .long
        formatter.isForFoodEnergyUse = true
        formatter.numberFormatter.maximumFractionDigits = 2
        return formatter
    }()
    fileprivate lazy var distanceFormatter: LengthFormatter = {
        let formatter = LengthFormatter()
        formatter.unitStyle = .long
        //        formatter.isForFoodEnergyUse = true
        formatter.numberFormatter.maximumFractionDigits = 2
        return formatter
    }()
}

extension ViewController {
    
    @IBAction func btnClickFetchData(_ sender: AnyObject) {
        
        self.fetchDataFromHealthKit()
    }
    
    func fetchDataFromHealthKit() {
        
        self.loadPrancerciseWorkouts { (workOutList, error) in
            if let workoutlist = workOutList {
                for i in 0..<(workoutlist.count) {
                    if let caloriesBurned = workoutlist[i].totalEnergyBurned?.doubleValue(for: HKUnit.kilocalorie()) {
                        let formattedCalories = String(format: "CaloriesBurned: %.2f", caloriesBurned)
                        print(formattedCalories)
                    }
                    
                    if let caloriesBurned = workoutlist[i].totalDistance?.doubleValue(for: HKUnit.meter()) {
                        let formattedCalories = String(format: "Total Distance: %.2f", caloriesBurned)
                        print(formattedCalories)
                    }
                    
                }
            }
        }
        
//        self.getStepCount()
//        self.getWorkOut()
//        self.checkWorkOut()
        /*
        let todayPredicate = predicateForSamplesToday()
        self.healthStore?.aapl_mostRecentWorkoutType(HKSampleType.workoutType(), predicate: todayPredicate, completion: { (workoutList, error) in
            
            if let workoutlist = workoutList {
                for i in 0..<(workoutlist.count) {
                    if let caloriesBurned = workoutlist[i].totalEnergyBurned?.doubleValue(for: HKUnit.kilocalorie()) {
                        let formattedCalories = String(format: "CaloriesBurned: %.2f", caloriesBurned)
                        print(formattedCalories)
                    }
                    
                    if let caloriesBurned = workoutlist[i].totalDistance?.doubleValue(for: HKUnit.meter()) {
                        let formattedCalories = String(format: "Total Distance: %.2f", caloriesBurned)
                        print(formattedCalories)
                    }
                    
                }
            }
        })
 */
        
//        self.healthStore?.aapl_mostRecentQuantitySampleOfType(weightType!, predicate: todayPredicate) {weight, error in
//            if weight == nil {
//                completion(nil, error)
//
//                return
//            }
        
//        self.getWeeklyStepCount()
        self.getStepCount()
    }
    
    func getStepCount() {
        
        let energyConsumedType = HKObjectType.quantityType(forIdentifier: HKQuantityTypeIdentifier.dietaryEnergyConsumed)
        let activeEnergyBurnType = HKObjectType.quantityType(forIdentifier: HKQuantityTypeIdentifier.activeEnergyBurned)
        let distanceWalking = HKObjectType.quantityType(forIdentifier: HKQuantityTypeIdentifier.distanceWalkingRunning)
        
        self.getTodayTotalSteps(completion: { (stepCount) in
            print("My Step: \(stepCount)")
            
            self.fetchSumOfSamplesTodayForType(energyConsumedType!, unit: HKUnit.joule()) {totalJoulesConsumed, error in
                
                //self.fetchSumOfSamplesTodayForType(activeEnergyBurnType!, unit: HKUnit.joule()) {activeEnergyBurned, error in
                self.fetchSumTodayForType(activeEnergyBurnType!, unit: HKUnit.joule()) {activeEnergyBurned, error in
                    
                    self.fetchSumOfSamplesTodayForType(distanceWalking!, unit: HKUnit.meter()) {distanceWalking, error in
                        
                        // Last, calculate the user's basal energy burn so far today.
                        self.fetchTotalBasalBurn {basalEnergyBurn, error in
                            
                            if basalEnergyBurn == nil {
                                NSLog("An error occurred trying to compute the basal energy burn. In your app, handle this gracefully. Error: \(error?.localizedDescription ?? "nil")")
                            }
                            
                            // Update the UI with all of the fetched values.
                            DispatchQueue.main.async {
                                
                                self.stepsCount = stepCount
                                
                                self.activeEnergyBurned = activeEnergyBurned
                                
                                self.restingEnergyBurned = basalEnergyBurn?.doubleValue(for: HKUnit.joule()) ?? 0.0
                                
                                self.energyConsumed = totalJoulesConsumed
                                
                                self.distance = distanceWalking
                                
                                self.netEnergy = self.energyConsumed - self.activeEnergyBurned - self.restingEnergyBurned
                            }
                        }
                    }
                }
                
            }
        })
        
//        self.retrieveStepCount { (step) in
//            print("Retrive Step: \(step)")
//            DispatchQueue.main.async {
//                self.IBlblStepCount.text = "Steps Count: \(step)"
//            }
//        }
    }
    
    
    func getWorkOut() {
        
        
        let sampleType = HKObjectType.workoutType()
        
        guard let distanceType = HKObjectType.quantityType(forIdentifier: .distanceWalkingRunning) else {
            fatalError("*** Unable to create the distance type ***")
        }
        let calendar = NSCalendar.current
        let endDate = Date()
        
        var steps = 0.0
        //            let lastMonth = NSCalendar.current.date(byAdding: .day, value: -30, to: Date())
        let startDate = calendar.date(byAdding: .day, value: -30, to: endDate)
        
        let workOut = HKWorkout(activityType: .walking, start: startDate!, end: endDate)
        
        let workoutPredicate = HKQuery.predicateForObjects(from: workOut)
        
        let startDateSort =
            NSSortDescriptor(key: HKSampleSortIdentifierStartDate, ascending: true)
        
        
        
        let query = HKSampleQuery(sampleType: distanceType, predicate: workoutPredicate,
                                  limit: HKObjectQueryNoLimit, sortDescriptors: nil) {
                                    (sampleQuery, results, error) -> Void in
                                    
                                    guard let distanceSamples = results as? [HKQuantitySample] else {
                                        // Perform proper error handling here...
                                        fatalError("*** An error occurred while adding a sample to " +
                                            "the workout: \(error?.localizedDescription)")
                                    }
                                    print(distanceSamples.count)
                                    // process the detailed samples...
                                    
        }
        
        healthStore?.execute(query)
    }
    
    func checkWorkOut(){
        let sampleType = HKObjectType.workoutType()
        let startDate = NSDate()
        let endDate = startDate.addingTimeInterval(-3600)
        let predicate = HKQuery.predicateForSamples(withStart: startDate as Date, end: endDate as Date, options: .strictStartDate)
        let sortDescriptor = NSSortDescriptor(key: HKSampleSortIdentifierEndDate, ascending: false)

        let limit = 0
        
        let query = HKSampleQuery(sampleType: sampleType, predicate: predicate, limit: limit, sortDescriptors: [sortDescriptor]) { (query, results, error) in
            
            var workouts: [HKWorkout] = []
            
            if let results = results {
                for result in results {
                    if let workout = result as? HKWorkout {
                        // Here's a HKWorkout object
                        workouts.append(workout)
                    }
                }
            }
            else {
                // No results were returned, check the error
            }
            print(workouts)
        }
        healthStore?.execute(query)
    }
    
    
    func loadPrancerciseWorkouts(completion: @escaping (([HKWorkout]?, Error?) -> Swift.Void)){
        
        //1. Get all workouts with the "Other" activity type.
        let workoutPredicate = HKQuery.predicateForWorkouts(with: .running)
        
        //2. Get all workouts that only came from this app.
//        let sourcePredicate = HKQuery.predicateForObjects(from: HKSource.default())
        
        //3. Combine the predicates into a single predicate.
        let compound = NSCompoundPredicate(andPredicateWithSubpredicates: [workoutPredicate])
        
        let sortDescriptor = NSSortDescriptor(key: HKSampleSortIdentifierEndDate,
                                              ascending: true)
        
        let todayPredicate = self.predicateForSamplesToday()
        let query = HKSampleQuery(sampleType: HKObjectType.workoutType(),
                                  predicate: nil,
                                  limit: 0,
                                  sortDescriptors: [sortDescriptor]) { (query, samples, error) in
                                    
                                    DispatchQueue.main.async {
                                        
                                        //4. Cast the samples as HKWorkout
                                        guard let samples = samples as? [HKWorkout],
                                            error == nil else {
                                                completion(nil, error)
                                                return
                                        }
                                        
                                        completion(samples, nil)
                                    }
        }

        healthStore?.execute(query)
    }

    
    func getWeeklyStepCount() {
        
        let calendar = NSCalendar.current
        
        let interval = NSDateComponents()
        interval.day = 1
        
        // Set the anchor date to Monday at 3:00 a.m.
        var anchorComponents = calendar.dateComponents([.day, .month, .year, .weekday], from: Date())
//        let anchorComponents = calendar.components([.Day, .Month, .Year, .Weekday], fromDate: NSDate())
        
        
        let offset = (7 + anchorComponents.weekday! - 2) % 7
        anchorComponents.day! -= offset
        anchorComponents.hour = 3
        guard let anchorDate = calendar.date(from: anchorComponents) else {
            fatalError("*** unable to create a valid date from the given components ***")
        }
        
        guard let quantityType = HKObjectType.quantityType(forIdentifier: HKQuantityTypeIdentifier.stepCount) else {
            fatalError("*** Unable to create a step count type ***")
        }
        
        // Create the query
        let query = HKStatisticsCollectionQuery(quantityType: quantityType,
                                                quantitySamplePredicate: nil,
                                                options: .cumulativeSum,
                                                anchorDate: anchorDate,
                                                intervalComponents: interval as DateComponents)
        
        // Set the results handler
        query.initialResultsHandler = {
            query, results, error in
            
            guard let statsCollection = results else {
                // Perform proper error handling here
                fatalError("*** An error occurred while calculating the statistics: \(error?.localizedDescription) ***")
            }
            
            let endDate = NSDate()
            guard let startDate = (calendar as NSCalendar).date(byAdding: .day, value: -7, to: endDate as Date, options: []) else {
                fatalError("*** Unable to calculate the start date ***")
            }
            
            // Plot the weekly step counts over the past 3 months
            statsCollection.enumerateStatistics(from: startDate, to: endDate as Date) { [unowned self] statistics, stop in
                
                if let quantity = statistics.sumQuantity() {
                    let date = statistics.startDate
                    let value = quantity.doubleValue(for: HKUnit.count())
                    
                    // Call a custom method to plot each data point.
//                    self.getWeeklyStepCount(value, forDate: date)
                    print("Vaule: \(value) and Date: \(date)")
                }
            }
        }
        
        healthStore?.execute(query)
    }
    
    
    func refreshStatistics() {
        
        let energyConsumedType = HKObjectType.quantityType(forIdentifier: HKQuantityTypeIdentifier.dietaryEnergyConsumed)
        let activeEnergyBurnType = HKObjectType.quantityType(forIdentifier: HKQuantityTypeIdentifier.activeEnergyBurned)
        let distanceWalking = HKObjectType.quantityType(forIdentifier: HKQuantityTypeIdentifier.distanceWalkingRunning)
        
        self.fetchSumOfSamplesTodayForType(energyConsumedType!, unit: HKUnit.joule()) {totalJoulesConsumed, error in
            
            self.fetchSumOfSamplesTodayForType(activeEnergyBurnType!, unit: HKUnit.joule()) {activeEnergyBurned, error in
                
                self.fetchSumOfSamplesTodayForType(distanceWalking!, unit: HKUnit.meter()) {distanceWalking, error in
                    
                    // Last, calculate the user's basal energy burn so far today.
                    self.fetchTotalBasalBurn {basalEnergyBurn, error in
                        
                        if basalEnergyBurn == nil {
                            NSLog("An error occurred trying to compute the basal energy burn. In your app, handle this gracefully. Error: \(error?.localizedDescription ?? "nil")")
                        }
                        
                        // Update the UI with all of the fetched values.
                        DispatchQueue.main.async {
                            self.activeEnergyBurned = activeEnergyBurned
                            
                            self.restingEnergyBurned = basalEnergyBurn?.doubleValue(for: HKUnit.joule()) ?? 0.0
                            
                            self.energyConsumed = totalJoulesConsumed
                            
                            self.distance = distanceWalking
                            
                            self.netEnergy = self.energyConsumed - self.activeEnergyBurned - self.restingEnergyBurned
                        }
                    }
                }
            }
            
        }
    }
    
    
   fileprivate func predicateTodaySamples() -> NSPredicate {
        let calendar = Calendar.current
        
        let now = Date()
        
        let startDate = calendar.startOfDay(for: now)
        let endDate = (calendar as NSCalendar).date(byAdding: .day, value: 1, to: startDate, options: [])
        
        return HKQuery.predicateForSamples(withStart: startDate, end: endDate, options: .strictStartDate)
    }
}

extension ViewController {
    
    //MARK: - Setter Overrides
    
    fileprivate func didSetStepCount(_ oldValue: Double) {
        DispatchQueue.main.async {
            self.IBlblStepCount?.text = "Step Count:  " + "\(self.stepsCount)"
        }
    }
    
    
    fileprivate func didSetActiveEnergyBurned(_ oldValue: Double) {
        DispatchQueue.main.async {
            self.IBlblActive?.text = "Active Energy:  " + self.energyFormatter.string(fromJoules: self.activeEnergyBurned)
        }
    }
    
    fileprivate func didSetEnergyConsumed(_ oldValue: Double) {
        DispatchQueue.main.async {
            self.IBlblConsumed?.text = "Consumed Energy:  " + self.energyFormatter.string(fromJoules: self.energyConsumed)
        }
    }
    
    fileprivate func didSetRestingEnergyBurned(_ oldValue: Double) {
        DispatchQueue.main.async {
            self.IBlblResting?.text = "Resting Energy:  " + self.energyFormatter.string(fromJoules: self.restingEnergyBurned)
        }
    }
    
    fileprivate func didSetNetEnergy(_ oldValue: Double) {
        DispatchQueue.main.async {
            self.IBlblNet?.text = "Total Energy:  " + self.energyFormatter.string(fromJoules: self.netEnergy)
        }
    }
    
    fileprivate func didSetDistance(_ oldValue: Double) {
        DispatchQueue.main.async {
            self.IBlblDistancve?.text = "Distnace:  " + self.distanceFormatter.string(fromMeters: self.distance)
        }
    }
    
    func checkHealthKitAvaibility() {
        
        if HKHealthStore.isHealthDataAvailable() {
            let writeDataTypes = self.dataTypesToWrite()
            let readDataTypes = self.dataTypesToRead()
            self.healthStore?.requestAuthorization(toShare: writeDataTypes, read: readDataTypes) {success, error in
                if !success {
                    NSLog("You didn't allow HealthKit to access these read/write data types. In your app, try to handle this error gracefully when a user decides not to provide access. The error was: \(error!). If you're using a simulator, try it on a device.")
                    
                    return
                }
                
                DispatchQueue.main.async {
                    
                }
            }
        }
    }
    
    func checkAvaibility() {
        
        
        if HKHealthStore.isHealthDataAvailable() {
            print("Yes, Helth data available!")
            
            //            let stepCount = NSSet(object: HKQuantityType.quantityType(forIdentifier: .stepCount)!)
            //            let weightType = HKObjectType.quantityType(forIdentifier: HKQuantityTypeIdentifier.bodyMass)
            //            let heightType = HKObjectType.quantityType(forIdentifier: HKQuantityTypeIdentifier.height)
            let readObject = NSSet(objects: HKQuantityType.quantityType(forIdentifier: .stepCount)!,HKQuantityType.quantityType(forIdentifier: .distanceWalkingRunning)!,HKQuantityType.quantityType(forIdentifier: .dietaryEnergyConsumed)!,HKQuantityType.quantityType(forIdentifier: .activeEnergyBurned)!,HKQuantityType.quantityType(forIdentifier: .basalEnergyBurned)!,HKQuantityType.quantityType(forIdentifier: .bodyMass)!,HKQuantityType.quantityType(forIdentifier: .height)!)
            
            //            let readDataTypes = self.dataTypesToRead()
            
            //            let shareObject = NSSet(objects: HKQuantityType.quantityType(forIdentifier: .bodyMass)!,HKQuantityType.quantityType(forIdentifier: .bodyMass)!,HKQuantityType.quantityType(forIdentifier: .bodyMassIndex)!)
            
            healthStore?.requestAuthorization(toShare: readObject as? Set<HKSampleType>, read: readObject as? Set<HKSampleType>, completion: { (result, error) in
            })
            
            //            healthStore.requestAuthorization(toShare: shareObject as? Set<HKSampleType>, read: stepCount as? Set<HKObjectType>, completion: { (success, error) in
            //                isAvailable = success
            //            })
            
        } else {
            print("No, Helth data available!")
        }
    }
    
    // Returns the types of data that Fit wishes to write to HealthKit.
    private func dataTypesToWrite() -> Set<HKSampleType> {
//        let dietaryCalorieEnergyType = HKObjectType.quantityType(forIdentifier: HKQuantityTypeIdentifier.dietaryEnergyConsumed)!
//        let activeEnergyBurnType = HKObjectType.quantityType(forIdentifier: HKQuantityTypeIdentifier.activeEnergyBurned)!
//        let heightType = HKObjectType.quantityType(forIdentifier: HKQuantityTypeIdentifier.height)!
//        let weightType = HKObjectType.quantityType(forIdentifier: HKQuantityTypeIdentifier.bodyMass)!
        
        let stepCount = HKSampleType.quantityType(forIdentifier: HKQuantityTypeIdentifier.stepCount)!
        let distanceWalking = HKSampleType.quantityType(forIdentifier: HKQuantityTypeIdentifier.distanceWalkingRunning)!
        let dietaryCalorieEnergyType = HKSampleType.quantityType(forIdentifier: HKQuantityTypeIdentifier.dietaryEnergyConsumed)!
        let activeEnergyBurnType = HKSampleType.quantityType(forIdentifier: HKQuantityTypeIdentifier.activeEnergyBurned)!
        let restingEnnergyBurnType = HKSampleType.quantityType(forIdentifier: HKQuantityTypeIdentifier.basalEnergyBurned)!
        let heightType = HKSampleType.quantityType(forIdentifier: HKQuantityTypeIdentifier.height)!
        let weightType = HKSampleType.quantityType(forIdentifier: HKQuantityTypeIdentifier.bodyMass)!
//        let birthdayType = HKSampleType.characteristicType(forIdentifier: HKCharacteristicTypeIdentifier.dateOfBirth)!
        let biologicalSexType = HKSampleType.characteristicType(forIdentifier: HKCharacteristicTypeIdentifier.biologicalSex)!
        let workOutType = HKSampleType.workoutType()
        
        return [stepCount, distanceWalking, dietaryCalorieEnergyType, activeEnergyBurnType, restingEnnergyBurnType, heightType, weightType, workOutType]
        
    }
    
    // Returns the types of data that Fit wishes to read from HealthKit.
    private func dataTypesToRead() -> Set<HKObjectType> {
        let stepCount = HKObjectType.quantityType(forIdentifier: HKQuantityTypeIdentifier.stepCount)!
        let distanceWalking = HKObjectType.quantityType(forIdentifier: HKQuantityTypeIdentifier.distanceWalkingRunning)!
        let dietaryCalorieEnergyType = HKObjectType.quantityType(forIdentifier: HKQuantityTypeIdentifier.dietaryEnergyConsumed)!
        let activeEnergyBurnType = HKObjectType.quantityType(forIdentifier: HKQuantityTypeIdentifier.activeEnergyBurned)!
        let restingEnnergyBurnType = HKObjectType.quantityType(forIdentifier: HKQuantityTypeIdentifier.basalEnergyBurned)!
        let heightType = HKObjectType.quantityType(forIdentifier: HKQuantityTypeIdentifier.height)!
        let weightType = HKObjectType.quantityType(forIdentifier: HKQuantityTypeIdentifier.bodyMass)!
        let birthdayType = HKObjectType.characteristicType(forIdentifier: HKCharacteristicTypeIdentifier.dateOfBirth)!
        let biologicalSexType = HKObjectType.characteristicType(forIdentifier: HKCharacteristicTypeIdentifier.biologicalSex)!
        let workOutType = HKObjectType.workoutType()
        return [stepCount, distanceWalking, dietaryCalorieEnergyType, activeEnergyBurnType, restingEnnergyBurnType, heightType, weightType, birthdayType, biologicalSexType, workOutType]
    }
    
    fileprivate func fetchSumOfSamplesTodayForType(_ quantityType: HKQuantityType, unit: HKUnit, completion completionHandler: ((Double, Error?)->Void)?) {
        let predicate = predicateForSamplesToday()
        
        let query = HKStatisticsQuery(quantityType: quantityType, quantitySamplePredicate: predicate, options: .cumulativeSum) {query, result, error in
            let sum = result?.sumQuantity()
            
            if completionHandler != nil {
                let value: Double = sum?.doubleValue(for: unit) ?? 0.0
                
                completionHandler!(value, error)
            }
        }
        
        self.healthStore?.execute(query)
    }
    
    fileprivate func fetchSumTodayForType(_ quantityType: HKQuantityType, unit: HKUnit, completion completionHandler: ((Double, Error?)->Void)?) {
        let predicate = predicateForSamplesToday()
        
//        let query = HKStatisticsQuery(quantityType: quantityType, quantitySamplePredicate: predicate, options: .cumulativeSum) {query, result, error in
//            let sum = result?.sumQuantity()
//            
//            if completionHandler != nil {
//                let value: Double = sum?.doubleValue(for: unit) ?? 0.0
//                
//                completionHandler!(value, error)
//            }
//        }
        
//        let type = HKSampleType.quantityType(forIdentifier: HKQuantityTypeIdentifier.stepCount) // The type of data we are requesting
        
        let calendar = NSCalendar.current
        let interval = NSDateComponents()
        interval.day = 1
        
        var anchorComponents = calendar.dateComponents([.day, .month, .year], from: Date())
        
        //        let anchorComponents = calendar.components([.Day , .Month , .Year], fromDate: NSDate())
        anchorComponents.hour = 0
        let anchorDate = calendar.date(from: anchorComponents)
        //        let anchorDate = calendar.dateFromComponents(anchorComponents)
        
        let stepsQuery = HKStatisticsCollectionQuery(quantityType: quantityType, quantitySamplePredicate: nil, options: .cumulativeSum, anchorDate: anchorDate!, intervalComponents: interval as DateComponents)
        stepsQuery.initialResultsHandler = {query, results, error in
            let endDate = Date()
            
            var steps = 0.0
            //            let lastMonth = NSCalendar.current.date(byAdding: .day, value: -30, to: Date())
            let startDate = calendar.date(byAdding: .day, value: 0, to: endDate)
            //            let startDate = calendar.dateByAddingUnit(.Day, value: 0, toDate: endDate, options: [])
            if let myResults = results{  myResults.enumerateStatistics(from: startDate!, to: endDate) { statistics, stop in
                if let quantity = statistics.sumQuantity(){
                    let date = statistics.startDate
//                    steps = quantity.doubleValue(for: HKUnit.count())
                    steps = quantity.doubleValue(for: unit) ?? 0.0
                    print("\(date): steps = \(steps)")
                }
                completionHandler!(steps, error)
                
                }
            } else {
                completionHandler!(steps, error)
            }
        }
        
        self.healthStore?.execute(stepsQuery)
    }
    
    //getSteps
    fileprivate func getTodayTotalSteps(completion: @escaping (_ stepRetrieved: Double) -> Void) {
        
        let type = HKSampleType.quantityType(forIdentifier: HKQuantityTypeIdentifier.stepCount) // The type of data we are requesting
        
        let calendar = NSCalendar.current
        let interval = NSDateComponents()
        interval.day = 1
        
        var anchorComponents = calendar.dateComponents([.day, .month, .year], from: Date())
        
        //        let anchorComponents = calendar.components([.Day , .Month , .Year], fromDate: NSDate())
        anchorComponents.hour = 0
        let anchorDate = calendar.date(from: anchorComponents)
        //        let anchorDate = calendar.dateFromComponents(anchorComponents)
        
        let stepsQuery = HKStatisticsCollectionQuery(quantityType: type!, quantitySamplePredicate: nil, options: .cumulativeSum, anchorDate: anchorDate!, intervalComponents: interval as DateComponents)
        
        stepsQuery.initialResultsHandler = {query, results, error in
            let endDate = Date()
            
            var steps = 0.0
            //            let lastMonth = NSCalendar.current.date(byAdding: .day, value: -30, to: Date())
            let startDate = calendar.date(byAdding: .day, value: 0, to: endDate)
            //            let startDate = calendar.dateByAddingUnit(.Day, value: 0, toDate: endDate, options: [])
            if let myResults = results{  myResults.enumerateStatistics(from: startDate!, to: endDate) { statistics, stop in
                if let quantity = statistics.sumQuantity(){
                    let date = statistics.startDate
                    steps = quantity.doubleValue(for: HKUnit.count())
                    print("\(date): steps = \(steps)")
                }
                completion(steps)
                }
            } else {
                
                completion(steps)
            }
        }
        healthStore?.execute(stepsQuery)
    }
    
    fileprivate func retrieveStepCount(completion: @escaping (_ stepRetrieved: Double) -> Void) {
        
        //   Define the Step Quantity Type
        let stepsCount = HKQuantityType.quantityType(forIdentifier: HKQuantityTypeIdentifier.stepCount)
        
        //   Get the start of the day
        let date = Date()
        let cal = Calendar(identifier: Calendar.Identifier.gregorian)
        let newDate = cal.startOfDay(for: date)
        let calendar = NSCalendar.current
        //  Set the Predicates & Interval
        let predicate = HKQuery.predicateForSamples(withStart: newDate, end: Date(), options: .strictStartDate)
        var interval = DateComponents()
        interval.day = 1
        
        //  Perform the Query
        let query = HKStatisticsCollectionQuery(quantityType: stepsCount!, quantitySamplePredicate: predicate, options: [.cumulativeSum], anchorDate: newDate as Date, intervalComponents:interval)
        
        query.initialResultsHandler = { query, results, error in
            
            if error != nil {
                
                //  Something went Wrong
                return
            }
            
            if let myResults = results{
                let endDate = Date()
                var steps = 0.0
                let startDate = calendar.date(byAdding: .day, value: 0, to: endDate)
                myResults.enumerateStatistics(from: startDate!, to: endDate) {
                    statistics, stop in
                    
                    if let quantity = statistics.sumQuantity() {
                        
                        let steps = quantity.doubleValue(for: HKUnit.count())
                        
                        print("Steps = \(steps)")
                        completion(steps)
                        
                    }
                }
            }
            
            
        }
        
        healthStore?.execute(query)
    }
    // Calculates the user's total basal (resting) energy burn based off of their height, weight, age,
    // and biological sex. If there is not enough information, return an error.
    fileprivate func fetchTotalBasalBurn(_ completion: @escaping (HKQuantity?, Error?)->Void) {
        let todayPredicate = predicateForSamplesToday()
        
        let weightType = HKObjectType.quantityType(forIdentifier: HKQuantityTypeIdentifier.bodyMass)
        let heightType = HKObjectType.quantityType(forIdentifier: HKQuantityTypeIdentifier.height)
        
        self.healthStore?.aapl_mostRecentQuantitySampleOfType(weightType!, predicate: todayPredicate) {weight, error in
            if weight == nil {
                completion(nil, error)
                
                return
            }
            
            self.healthStore?.aapl_mostRecentQuantitySampleOfType(heightType!, predicate: todayPredicate) {height, error in //NOTE: this error may have NSError from aapl_mostRecentQuantitySampleOfType
                if height == nil {
                    completion(nil, error)
                    
                    return
                }
                
                let dateOfBirth: Date?
                do {
                    dateOfBirth = try self.healthStore?.dateOfBirth()
                } catch let error {
                    completion(nil, error)
                    
                    return
                }
                
                let biologicalSexObject: HKBiologicalSexObject?
                do {
                    biologicalSexObject = try self.healthStore?.biologicalSex()
                } catch let error {
                    completion(nil, error)
                    
                    return
                }
                
                // Once we have pulled all of the information without errors, calculate the user's total basal energy burn
                let basalEnergyBurn = self.calculateBasalBurnTodayFromWeight(weight!, height: height!, dateOfBirth: dateOfBirth!, biologicalSex: biologicalSexObject!)
                
                completion(basalEnergyBurn, nil)
            }
        }
    }
    
    fileprivate func calculateBasalBurnTodayFromWeight(_ weight: HKQuantity, height: HKQuantity, dateOfBirth: Date, biologicalSex: HKBiologicalSexObject) -> HKQuantity {
        // Only calculate Basal Metabolic Rate (BMR) if we have enough information about the user
        
        // Note the difference between calling +unitFromString: vs creating a unit from a string with
        // a given prefix. Both of these are equally valid, however one may be more convenient for a given
        // use case.
        let heightInCentimeters = height.doubleValue(for: HKUnit(from: "cm"))
        let weightInKilograms = weight.doubleValue(for: HKUnit.gramUnit(with: .kilo))
        //
        let now = Date()
        //### I couldn't have found an equivalent of `options: .wrapComponents` in Calendar methods.
        let ageComponents = (Calendar.current as NSCalendar).components(.year, from: dateOfBirth, to: now, options: .wrapComponents)
        let ageInYears = ageComponents.year
        
        // BMR is calculated in kilocalories per day.
        let BMR = self.calculateBMRFromWeight(weightInKilograms, height: heightInCentimeters, age: ageInYears!, biologicalSex: biologicalSex.biologicalSex)
        
        // Figure out how much of today has completed so we know how many kilocalories the user has burned.
        let startOfToday = Calendar.current.startOfDay(for: now)
        let endOfToday = (Calendar.current as NSCalendar).date(byAdding: .day, value: 1, to: startOfToday, options: [])
        
        let secondsInDay = endOfToday!.timeIntervalSince(startOfToday)
        let percentOfDayComplete = now.timeIntervalSince(startOfToday) / secondsInDay
        
        let kilocaloriesBurned = BMR * percentOfDayComplete
        
        return HKQuantity(unit: HKUnit.kilocalorie(), doubleValue: kilocaloriesBurned)
    }
    
    //MARK: - Convenience
    
    fileprivate func predicateForSamplesToday() -> NSPredicate {
        let calendar = Calendar.current
        
        let now = Date()
        
        let startDate = calendar.startOfDay(for: now)
        let endDate = (calendar as NSCalendar).date(byAdding: .day, value: 1, to: startDate, options: [])
        
        return HKQuery.predicateForSamples(withStart: startDate, end: endDate, options: .strictStartDate)
    }
    
    /// Returns BMR value in kilocalories per day. Note that there are different ways of calculating the
    /// BMR. In this example we chose an arbitrary function to calculate BMR based on weight, height, age,
    /// and biological sex.
    private func calculateBMRFromWeight(_ weightInKilograms: Double, height heightInCentimeters: Double, age ageInYears: Int, biologicalSex: HKBiologicalSex) -> Double {
        var BMR: Double = 0.0
        
        // The BMR equation is different between males and females.
        if biologicalSex == .male {
            BMR = 66.0 + (13.8 * weightInKilograms) + (5.0 * heightInCentimeters) - (6.8 * Double(ageInYears))
        } else {
            BMR = 655 + (9.6 * weightInKilograms) + (1.8 * heightInCentimeters) - (4.7 * Double(ageInYears))
        }
        
        return BMR
    }
}


