//
//  SecurityDataProvider.swift
//  iOSProject
//
//  Created by Kaira NewMac on 12/8/16.
//  Copyright © 2016 Kaira NewMac. All rights reserved.
//

import UIKit
import ObjectMapper

class SecurityDataProvider: NSObject {
    
    

    
    //Login
    func Login (loginModel : LoginPostModel,IsLoader:Bool? = true, viewController:UIViewController? = nil, ServiceCallBack: @escaping (_ response: ServiceResponse<LoginGetModel>?, _ IsSuccess: Bool?)-> Void! )
    {
        let serviceRequest = ServiceRequest<LoginPostModel>()
        serviceRequest.Data = loginModel
        let JSONString = Mapper().toJSON(serviceRequest)
        ServiceRequestResponse.servicecall(IsLoader:IsLoader, url: ServiceUrl.Login, HttpMethod: .post, InputParameter:JSONString, viewController: viewController) { (result:String?, IsSuccess:Bool?) -> Void in
            
            if IsSuccess == true {
                
                let serviceResponse = Mapper<ServiceResponse<LoginGetModel>>().map(JSONString: result!)
//                self.setPreferense(serviceResponse: serviceResponse!)
//                if Preference.GetBool(key: UserDefaultsKey.IsVerify) {
//                    appDelegate.window?.rootViewController?.view.makeToast(message: AppMessage.LoginSuccessfull)
//                }else {
//                    appDelegate.window?.rootViewController?.view.makeToast(message: AppMessage.OTPSent)
//                }
                ServiceCallBack(serviceResponse!, true)
                
                
            }else{
//                appDelegate.window?.rootViewController?.view.makeToast(message: AppMessage.LoginTryAgain)
                ServiceCallBack(nil, false)
            }
        }
    }
    
    //postuserhealthactivity
    func HealthActivity (healthActivity : HealthActivityPost,IsLoader:Bool? = true, viewController:UIViewController? = nil, ServiceCallBack: @escaping (_ response: ServiceResponse<HealthActivity>?, _ IsSuccess: Bool?)-> Void! )
    {
        let serviceRequest = ServiceRequest<HealthActivityPost>()
        serviceRequest.Data = healthActivity
        let JSONString = Mapper().toJSON(serviceRequest)
        ServiceRequestResponse.servicecall(IsLoader:IsLoader, url: ServiceUrl.HealthActivity, HttpMethod: .post, InputParameter:JSONString, viewController: viewController) { (result:String?, IsSuccess:Bool?) -> Void in
            
            if IsSuccess == true {
                
                let serviceResponse = Mapper<ServiceResponse<HealthActivity>>().map(JSONString: result!)
                ServiceCallBack(serviceResponse!, true)
                
                
            }else{
                //                appDelegate.window?.rootViewController?.view.makeToast(message: AppMessage.LoginTryAgain)
                ServiceCallBack(nil, false)
            }
        }
    }
    
}
