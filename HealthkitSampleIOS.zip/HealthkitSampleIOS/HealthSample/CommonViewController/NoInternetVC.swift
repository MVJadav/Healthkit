//
//  NoInternetVC.swift
//  iOSProject
//
//  Created by Kaira NewMac on 12/9/16.
//  Copyright © 2016 Kaira NewMac. All rights reserved.
//

import UIKit
import Alamofire

//MARK: Enum for Action Button
enum enumNoInternetOption {
    case None,
    Retry
}

class NoInternetVC: UIViewController {

    @IBOutlet weak var  btnclick: UIButton!
    
    var NoInternetCompletion: ((enumNoInternetOption) -> ())!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.frame = (appDelegate.window?.screen.bounds)!
    }
}

//MARK: IBAction Method
extension NoInternetVC {
    
    @IBAction func btnclickRetry(_ sender: Any) {
        if Reachability.isConnectedToNetwork() {
            NoInternetCompletion(.Retry)
            hideNoInternetVC()
        }
        else {
            _ = SCLAlertView().showError(AlertTitle.Error, subTitle:AppMessage.NoInternetConnection, closeButtonTitle:ButtonTitle.btnOk)
        }
    }
}
//MARK: Other Method
extension NoInternetVC {
    
    class func showNoInternetVC(completion completionHandler: @escaping ((enumNoInternetOption) -> () )) {
        
        let objNoInternetVC = NoInternetVC(nibName: "NoInternetVC", bundle: nil)
        objNoInternetVC.NoInternetCompletion = completionHandler
        appDelegate.window?.addSubview(objNoInternetVC.view)
        appDelegate.window?.rootViewController?.addChildViewController(objNoInternetVC)
        objNoInternetVC.didMove(toParentViewController: appDelegate.window?.rootViewController)
    }
    
    func hideNoInternetVC() {
        
        UIView.animate(withDuration: 0.2, delay: 0.0, options: UIViewAnimationOptions.curveEaseInOut, animations: {
            
            self.view.layoutIfNeeded()
            
        }, completion: {
            (value: Bool) in
            
            self.view.removeFromSuperview()
            self.removeFromParentViewController()
        })
    }
}
